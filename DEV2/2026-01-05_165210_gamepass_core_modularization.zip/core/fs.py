from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict


def ensure_dirs(out_dir: Path) -> Path:
    out_dir.mkdir(parents=True, exist_ok=True)
    meta_dir = out_dir / "_meta"
    meta_dir.mkdir(exist_ok=True)
    return meta_dir


def write_json(path: Path, obj: Any) -> None:
    path.write_text(json.dumps(obj, indent=2), encoding="utf-8")


def write_product(out_dir: Path, product: Dict[str, Any]) -> bool:
    pid = product.get("ProductId")
    if not isinstance(pid, str) or not pid:
        return False
    (out_dir / f"{pid}.json").write_text(json.dumps(product, indent=2), encoding="utf-8")
    return True
