# Game Pass Catalog Export

## What you get
- `gamepass_catalog.html` – Table + Tiles, with filters (Year/Genre/Rating) and Favorites ⭐ (stored in localStorage)
- `gamepass_catalog.csv`
- `cache/` – resume-safe caches for Store products + Wikidata (+ optional HLTB)

## Run
```bash
chmod +x gamepass.py
./gamepass.py
```

### Options
- `--reset-cache` – clear cache and start over
- `--no-wikidata` – skip Wikidata enrichment
- `--hltb` – try to fetch hours from HowLongToBeat (requires dependency)
- `--pass-size 100` – fetch pass size
- `--quiet` – less console output

## PEP 668 (Ubuntu/Debian) – install optional deps via venv
```bash
sudo apt install -y python3-venv python3-full
python3 -m venv .venv
source .venv/bin/activate
pip install howlongtobeatpy tqdm
./gamepass.py --hltb
```

> Without venv/extra deps, the script still works (hours empty, progress falls back to text).
