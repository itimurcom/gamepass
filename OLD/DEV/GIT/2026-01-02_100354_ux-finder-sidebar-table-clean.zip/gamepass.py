#!/usr/bin/env python3
# gamepass.py — Game Pass каталог -> HTML + CSV
#
# v3.0 baseline (зафіксовано):
# 1) Інтерфейс скрипта — українською
# 2) Дані про ігри — українською, якщо є офіційно (Store/Wikidata), інакше fallback на англійську
#    - Назви ігор залишаються оригінальні (як у Store).
# 3) Кеш завжди в ~/.gamepass (незалежно від папки запуску)
#
# UI/таблиця:
# - Платформи прибрані
# - Опис одразу після Жанру
# - Рейтинг: фіксована ширина + ellipsis; у таблиці показуємо лише число (0–100), джерело — tooltip
# - Перемикач Таблиця/Плитки, фільтри Рік/Жанр/Рейтинг, Обране ⭐ (localStorage), опис розкривається по кліку
#
# Запуск:
#   chmod +x gamepass.py
#   ./gamepass.py
#
# Опційно:
#   ./gamepass.py --reset-cache
#   ./gamepass.py --no-wikidata
#   ./gamepass.py --hltb        (потрібен howlongtobeatpy у venv)
#
# Примітка (Ubuntu/Debian, PEP 668):
#   python3 -m venv .venv && source .venv/bin/activate
#   pip install tqdm howlongtobeatpy

import argparse
import shutil
import csv
import html
import json
import os
import random
import sys
import time
import urllib.parse
import urllib.request
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple

# ---------- CLI ----------
def parse_args():
    p = argparse.ArgumentParser(description="Експортер каталогу Xbox Game Pass у HTML/CSV")
    p.add_argument("--quiet", action="store_true", help="Менше виводу в консоль.")
    p.add_argument("--no-color", action="store_true", help="Вимкнути кольори в консолі.")
    p.add_argument("--reset-cache", action="store_true", help="Очистити кеш і почати спочатку.")
    p.add_argument("--render-only", action="store_true", help="Тільки згенерувати HTML/CSV з кешу (~/.gamepass), без мережевих запитів")
    p.add_argument("--no-wikidata", action="store_true", help="Пропустити деталей через Wikidata.")
    p.add_argument("--hltb", action="store_true", help="Спробувати отримати години з HowLongToBeat (потрібен howlongtobeatpy).")
    p.add_argument("--market", default="US", help="Ринок (market), напр. US, UA, PL. За замовчуванням: US.")
    p.add_argument("--data-lang", default="uk-ua", help="Основна мова даних (Store/Wikidata). За замовчуванням: uk-ua.")
    p.add_argument("--fallback-lang", default="en-us", help="Fallback мова даних. За замовчуванням: en-us.")
    p.add_argument("--pass-size", type=int, default=100, help="Розмір порції для Store-запитів. За замовчуванням: 100.")
    p.add_argument("--sleep", type=float, default=0.20, help="Пауза між запитами (сек). За замовчуванням: 0.20.")
    return p.parse_args()

ARGS = parse_args()

# Optional tqdm
try:
    from tqdm import tqdm  # type: ignore
except Exception:
    tqdm = None

# ---------- Кольоровий вивід (ANSI) ----------
IS_TTY = sys.stdout.isatty()
USE_COLOR = (not ARGS.no_color) and IS_TTY

def _c(txt: str, kind: str) -> str:
    if not USE_COLOR:
        return txt
    m = {
        "reset": "\033[0m",
        "bold": "\033[1m",
        "red": "\033[31m",
        "green": "\033[32m",
        "yellow": "\033[33m",
        "blue": "\033[34m",
        "cyan": "\033[36m",
    }
    return m.get(kind, "") + txt + m["reset"]

def _tag(label: str, kind: str) -> str:
    return _c(f"[{label}]", kind)

# ---------- Settings ----------
MARKET = ARGS.market
DATA_LANG = ARGS.data_lang.lower()
FALLBACK_LANG = ARGS.fallback_lang.lower()

# Для Store в displaycatalog краще просити одразу 2 мови (дає 2 LocalizedProperties)
DISPLAY_LANGS = f"{DATA_LANG},{FALLBACK_LANG}"

SIGL_ALL = "29a81209-df6f-41fd-a528-2ae6b91f719c"  # Game Pass - All games

PASS_SIZE = max(1, int(ARGS.pass_size))
INITIAL_BATCH_SIZE = 40
MIN_BATCH_SIZE = 1

REQUEST_TIMEOUT_SEC = 25
RETRIES = 5
BACKOFF_BASE_SEC = 1.6
JITTER_SEC = 0.35
SLEEP_BETWEEN_REQUESTS_SEC = max(0.0, float(ARGS.sleep))

# Кеш завжди в ~/.gamepass
CACHE_DIR = os.path.join(os.path.expanduser("~"), ".gamepass")
STATE_FILE = os.path.join(CACHE_DIR, "state.json")
SIGL_FILE = os.path.join(CACHE_DIR, "sigl_ids.json")

PRODUCTS_DIR = os.path.join(CACHE_DIR, "products")
WIKIDATA_DIR = os.path.join(CACHE_DIR, "wikidata")      # name -> QID
WD_SPARQL_DIR = os.path.join(CACHE_DIR, "wd_sparql")    # QID -> enriched fields
HLTB_DIR = os.path.join(CACHE_DIR, "hltb")              # name -> hours

OUT_HTML = "gamepass_catalog.html"
OUT_CSV = "gamepass_catalog.csv"

# Бамп версії схеми, щоб старий кеш не плутався з новою мовною логікою
CACHE_SCHEMA_VERSION = 3

# ---------- Інформативний прогрес ----------
_last_heartbeat = 0.0
PHASE = "idle"
PHASE_DONE = 0
PHASE_TOTAL = 0
PHASE_ITEM = ""
PHASE_START_TS = 0.0

PHASE_LABELS = {
    "store": "МАГАЗИН",
    "enrich": "ДЕТАЛІ",
    "idle": "ОЧІКУВАННЯ",
}

def set_phase(name: str, total: int = 0):
    global PHASE, PHASE_DONE, PHASE_TOTAL, PHASE_ITEM, PHASE_START_TS
    PHASE = name
    PHASE_DONE = 0
    PHASE_TOTAL = int(total or 0)
    PHASE_ITEM = ""
    PHASE_START_TS = time.time()
    if sys.stdout.isatty():
        print()

def phase_step(n: int = 1, item: str = ""):
    global PHASE_DONE, PHASE_ITEM
    PHASE_DONE += int(n or 0)
    if item:
        PHASE_ITEM = item

def _fmt_time(sec: float) -> str:
    sec = int(max(0, sec))
    if sec < 60:
        return f"{sec}с"
    m = sec // 60
    s = sec % 60
    if m < 60:
        return f"{m}хв {s:02d}с"
    h = m // 60
    m2 = m % 60
    return f"{h}г {m2:02d}хв"

def _bar(done: int, total: int, width: int = 22) -> str:
    if total <= 0:
        return ""
    done = max(0, min(done, total))
    filled = int((done / total) * width)
    return "█" * filled + "░" * (width - filled)

_SPINNER = ["⠋","⠙","⠹","⠸","⠼","⠴","⠦","⠧","⠇","⠏"]
_SPIN_I = 0

def _fmt_time(sec: float) -> str:
    sec = int(max(0, sec))
    if sec < 60:
        return f"{sec}с"
    m = sec // 60
    s = sec % 60
    if m < 60:
        return f"{m}хв {s:02d}с"
    h = m // 60
    m2 = m % 60
    return f"{h}г {m2:02d}хв"

def _bar(done: int, total: int, width: int = 22) -> str:
    if total <= 0:
        return ""
    done = max(0, min(done, total))
    filled = int((done / total) * width)
    return "█" * filled + "░" * (width - filled)

_SPINNER = ["⠋","⠙","⠹","⠸","⠼","⠴","⠦","⠧","⠇","⠏"]
_SPIN_I = 0

def heartbeat(force: bool = False):
    global _last_heartbeat, _SPIN_I
    now = time.time()
    if not (force or (now - _last_heartbeat) >= 1.0):
        return
    _last_heartbeat = now

    done = PHASE_DONE
    total = PHASE_TOTAL
    item = PHASE_ITEM
    label = PHASE_LABELS.get(PHASE, PHASE.upper())

    elapsed = max(0.001, now - PHASE_START_TS)
    speed = done / elapsed if done > 0 else 0.0

    spin = _SPINNER[_SPIN_I % len(_SPINNER)]
    _SPIN_I += 1

    if total > 0:
        p = int((done / max(1, total)) * 100)
        bar = _bar(done, total)
        line = f"{_tag(label, 'green')} {spin} {bar} {p:3d}%  {done}/{total}  Швидкість: {speed:.1f}/с  Минуло: {_fmt_time(elapsed)}"
    else:
        line = f"{_tag(label, 'yellow')} {spin} Немає роботи (0 елементів)"

    if item and not ARGS.quiet:
        line += f" | {item}"

    # TTY: оновлюємо в одному рядку і повністю затираємо хвости
    if IS_TTY:
        try:
            width = shutil.get_terminal_size(fallback=(120, 20)).columns
            out = "\r" + line
            if len(out) < width:
                out = out + (" " * (width - len(out)))
            else:
                out = out[:width]
            sys.stdout.write(out)
            sys.stdout.flush()
            return
        except Exception:
            pass

    print(line)


def info(msg: str):
    if not ARGS.quiet:
        print(msg)

def warn(msg: str):
    print(_c(msg, 'yellow'))

# ---------- Cache helpers ----------
def ensure_dirs():
    os.makedirs(CACHE_DIR, exist_ok=True)
    os.makedirs(PRODUCTS_DIR, exist_ok=True)
    os.makedirs(WIKIDATA_DIR, exist_ok=True)
    os.makedirs(WD_SPARQL_DIR, exist_ok=True)
    os.makedirs(HLTB_DIR, exist_ok=True)

def read_json(path: str) -> Any:
    if not os.path.exists(path):
        return None
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None

def write_json_atomic(path: str, obj: Any):
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)
    os.replace(tmp, path)

def safe_filename(s: str) -> str:
    s = (s or "").strip().lower()
    out = "".join(c for c in s if c.isalnum() or c in ("-", "_"))[:180]
    return out if out else "x"

def product_cache_path(big_id: str) -> str:
    return os.path.join(PRODUCTS_DIR, f"{safe_filename(big_id)}.json")

def wd_name_cache_path(name: str) -> str:
    return os.path.join(WIKIDATA_DIR, f"{safe_filename(name)}.json")

def wd_qid_cache_path(qid: str) -> str:
    return os.path.join(WD_SPARQL_DIR, f"{safe_filename(qid)}.json")

def hltb_name_cache_path(name: str) -> str:
    return os.path.join(HLTB_DIR, f"{safe_filename(name)}.json")

def invalidate(path: str):
    try:
        if os.path.exists(path):
            os.remove(path)
    except Exception:
        pass

def is_valid_cached_product(obj: Any) -> bool:
    if not isinstance(obj, dict):
        return False
    if obj.get("_schema") != CACHE_SCHEMA_VERSION:
        return False
    # Мова важлива: продукт кешуємо для DISPLAY_LANGS
    if obj.get("display_langs") != DISPLAY_LANGS:
        return False
    product = obj.get("product")
    if not isinstance(product, dict):
        return False
    if not (obj.get("bigId") and isinstance(obj.get("bigId"), str)):
        return False
    if not isinstance(product.get("LocalizedProperties"), list):
        return False
    return True

def load_product_from_cache(big_id: str) -> Optional[dict]:
    path = product_cache_path(big_id)
    obj = read_json(path)
    # Fast-path: якщо файл існує і парситься, використовуємо кеш як є.
    # Це прибирає повторні завантаження деталей при зміні допоміжних полів кешу (market/data_lang тощо).
    if isinstance(obj, dict) and isinstance(obj.get("product"), dict):
        return obj
    if not is_valid_cached_product(obj):
        if obj is not None:
            invalidate(path)
        return None
    return obj["product"]

def save_product_to_cache(big_id: str, product: dict):
    write_json_atomic(product_cache_path(big_id), {
        "_schema": CACHE_SCHEMA_VERSION,
        "bigId": big_id,
        "display_langs": DISPLAY_LANGS,
        "cached_at": datetime.now().isoformat(),
        "product": product
    })

def prompt_resume_or_reset() -> str:
    if ARGS.reset_cache:
        return "reset"
    if not os.path.exists(STATE_FILE) and not os.path.exists(SIGL_FILE):
        return "resume"
    while True:
        ans = input("Є кеш. Перезавантажити ВСІ дані? [y/N]: ").strip().lower()
        if ans in ("y", "yes", "r", "reset"):
            return "reset"
        if ans in ("", "n", "no", "c", "continue"):
            return "resume"
        print("Будь ласка, введіть y або n.")
    

def reset_cache():
    for path in (STATE_FILE, SIGL_FILE):
        invalidate(path)
    for d in (PRODUCTS_DIR, WIKIDATA_DIR, WD_SPARQL_DIR, HLTB_DIR):
        if os.path.isdir(d):
            for fn in os.listdir(d):
                if fn.endswith(".json"):
                    invalidate(os.path.join(d, fn))
    print("Кеш очищено.")

# ---------- HTTP ----------
def http_get(url: str, headers: Optional[Dict[str, str]] = None) -> bytes:
    last_err = None
    for attempt in range(1, RETRIES + 1):
        try:
            req = urllib.request.Request(url)
            req.add_header("User-Agent", "Mozilla/5.0")
            if headers:
                for k, v in headers.items():
                    req.add_header(k, v)
            with urllib.request.urlopen(req, timeout=REQUEST_TIMEOUT_SEC) as resp:
                return resp.read()
        except Exception as e:
            last_err = e
            if attempt == RETRIES:
                break
            sleep_for = (BACKOFF_BASE_SEC ** attempt) + random.uniform(0, JITTER_SEC)
            warn(f"  ! Запит не вдався (спроба {attempt}/{RETRIES}): {e}")
            warn(f"  ! Пауза {sleep_for:.2f}с і повтор...")
            time.sleep(sleep_for)
    raise RuntimeError(f"Запит не вдався після {RETRIES} спроб: {url}\nОстання помилка: {last_err}")

def http_get_json(url: str, headers: Optional[Dict[str, str]] = None) -> Any:
    data = http_get(url, headers=headers or {"Accept": "application/json"})
    return json.loads(data.decode("utf-8", errors="replace"))

# ---------- SIGL ----------
def get_sigl_ids(sigl_id: str) -> List[str]:
    url = "https://catalog.gamepass.com/sigls/v2?" + urllib.parse.urlencode(
        {"id": sigl_id, "language": DATA_LANG, "market": MARKET}
    )
    data = http_get_json(url)

    ids: List[str] = []
    if isinstance(data, list):
        for item in data:
            if not isinstance(item, dict):
                continue
            big_id = item.get("id") or item.get("productId") or item.get("bigId")
            if big_id:
                ids.append(str(big_id))

    seen = set()
    out: List[str] = []
    for x in ids:
        if x not in seen:
            seen.add(x)
            out.append(x)
    return out

# ---------- Store fetch (autosplit) ----------
def fetch_products_once(big_ids: List[str]) -> Dict[str, dict]:
    if not big_ids:
        return {}
    url = "https://displaycatalog.mp.microsoft.com/v7.0/products?" + urllib.parse.urlencode(
        {"bigIds": ",".join(big_ids), "market": MARKET, "languages": DISPLAY_LANGS},
        quote_via=urllib.parse.quote,
    )
    data = http_get_json(url)
    out: Dict[str, dict] = {}
    plist = data.get("Products") if isinstance(data, dict) else None
    if isinstance(plist, list):
        for p in plist:
            if isinstance(p, dict):
                bid = p.get("ProductId") or p.get("BigId") or p.get("bigId")
                if bid:
                    out[str(bid)] = p
    return out

def fetch_products_reliably(request_ids: List[str], batch_size: int, progress_cb=None) -> Tuple[Dict[str, dict], List[str]]:
    products: Dict[str, dict] = {}
    missing: List[str] = []

    to_fetch: List[str] = []
    for bid in request_ids:
        cached = load_product_from_cache(bid)
        if cached:
            products[bid] = cached
        else:
            to_fetch.append(bid)

    if not to_fetch:
        return products, []

    def process_chunk(chunk: List[str], current_batch: int):
        nonlocal products, missing
        if not chunk:
            return

        if len(chunk) > current_batch:
            for i in range(0, len(chunk), current_batch):
                process_chunk(chunk[i:i + current_batch], current_batch)
            return

        got = fetch_products_once(chunk)

        for bid, pobj in got.items():
            products[bid] = pobj
            save_product_to_cache(bid, pobj)
            if progress_cb:
                progress_cb(1)

        not_returned = [bid for bid in chunk if bid not in got]
        if not not_returned:
            return

        if current_batch > MIN_BATCH_SIZE and len(chunk) > 1:
            next_batch = max(MIN_BATCH_SIZE, current_batch // 2)
            process_chunk(not_returned, next_batch)
            return

        for bid in not_returned:
            if bid not in missing:
                missing.append(bid)
                if progress_cb:
                    progress_cb(1)

    process_chunk(to_fetch, batch_size)
    return products, missing

# ---------- Extractors / normalization ----------
def pick_first(lst):
    if isinstance(lst, list) and lst:
        return lst[0]
    return None

def normalize_image_url(u: str) -> str:
    u = (u or "").strip()
    if not u:
        return ""
    if u.startswith("//"):
        return "https:" + u
    return u

def iter_localized_images(obj: Any) -> List[dict]:
    images: List[dict] = []
    if isinstance(obj, dict):
        imgs = obj.get("Images")
        if isinstance(imgs, list):
            images.extend([x for x in imgs if isinstance(x, dict)])
    elif isinstance(obj, list):
        for lp in obj:
            if isinstance(lp, dict):
                imgs = lp.get("Images")
                if isinstance(imgs, list):
                    images.extend([x for x in imgs if isinstance(x, dict)])
    return images

def image_tag(img: dict) -> str:
    return str(img.get("ImagePurpose") or img.get("ImagePurposeTag") or img.get("Purpose") or "")

def image_url(img: dict) -> str:
    return str(img.get("Uri") or img.get("Url") or img.get("uri") or img.get("url") or "")

def pick_best_image_from_images(images: List[dict]) -> str:
    if not images:
        return ""
    preferred = ["BoxArt", "Poster", "SuperHeroArt", "BrandedKeyArt", "KeyArt", "Tile", "Screenshot", "Background"]
    for tag in preferred:
        for img in images:
            if image_tag(img).lower() == tag.lower():
                u = normalize_image_url(image_url(img))
                if u:
                    return u
    for img in images:
        u = normalize_image_url(image_url(img))
        if u:
            return u
    return ""

def pick_best_image_url(product: dict) -> str:
    u = pick_best_image_from_images(iter_localized_images(product.get("LocalizedProperties")))
    if u:
        return u
    dsa = product.get("DisplaySkuAvailabilities")
    if isinstance(dsa, list) and dsa:
        sku = (dsa[0] or {}).get("Sku") or {}
        u2 = pick_best_image_from_images(iter_localized_images(sku.get("LocalizedProperties")))
        if u2:
            return u2
    return ""

def normalize_year(y: str) -> str:
    y = (y or "").strip()
    if len(y) >= 4 and y[:4].isdigit():
        yy = int(y[:4])
        if 1970 <= yy <= 2035:
            return str(yy)
    return ""

def normalize_rating(r: str) -> str:
    r = (r or "").strip()
    if not r:
        return ""
    try:
        v = int(float(r))
        if 0 <= v <= 100:
            return str(v)
    except Exception:
        return ""
    return ""

def normalize_genres(g: str) -> str:
    g = (g or "").strip()
    if not g:
        return ""
    parts = [p.strip() for p in g.split(",") if p.strip()]
    seen = set()
    out = []
    for p in parts:
        key = p.lower()
        if key not in seen:
            seen.add(key)
            out.append(p)
    return ", ".join(out)

def pick_localized_block(product: dict, preferred_lang: str, fallback_lang: str) -> dict:
    # DisplayCatalog повертає LocalizedProperties з Language. Беремо uk-ua якщо є, інакше en-us.
    lps = product.get("LocalizedProperties")
    if not isinstance(lps, list):
        return {}
    pref = None
    fb = None
    for lp in lps:
        if not isinstance(lp, dict):
            continue
        lang = (lp.get("Language") or lp.get("language") or "").lower()
        if lang == preferred_lang:
            pref = lp
        if lang == fallback_lang:
            fb = lp
    return pref or fb or (lps[0] if lps else {}) or {}

def extract_store_fields(product: dict) -> dict:
    lp = pick_localized_block(product, DATA_LANG, FALLBACK_LANG)
    props = pick_first(product.get("Properties")) or {}

    title = lp.get("ProductTitle") or product.get("ProductTitle") or ""
    publisher = lp.get("PublisherName") or ""
    developer = lp.get("DeveloperName") or ""
    short_desc = lp.get("ShortDescription") or ""

    # Store жанри/категорії (fallback, якщо Wikidata нічого не дала)
    store_genres = ""
    try:
        cats = props.get("Categories") or props.get("Category") or props.get("Genres") or props.get("Genre") or ""
        if isinstance(cats, list):
            parts = []
            for c in cats:
                if isinstance(c, str):
                    parts.append(c)
                elif isinstance(c, dict):
                    parts.append(c.get("Name") or c.get("DisplayName") or c.get("name") or "")
            store_genres = ", ".join([p for p in parts if p])
        elif isinstance(cats, str):
            store_genres = cats
    except Exception:
        store_genres = ""
    store_genres = normalize_genres(store_genres)

    release_date = props.get("OriginalReleaseDate") or props.get("ReleaseDate") or props.get("ReleaseDateUtc") or ""
    store_year = normalize_year(release_date)

    image_url_final = normalize_image_url(pick_best_image_url(product))

    return {
        "Name": (title or "").strip(),
        "Publisher": (publisher or "").strip(),
        "Developer": (developer or "").strip(),
        "StoreYear": store_year,
        "ImageUrl": (image_url_final or "").strip(),
        "ShortDescription": (short_desc or "").strip(),
        "StoreGenres": (store_genres or "").strip(),
    }

def clean_title_for_search(name: str) -> str:
    n = (name or "").strip()
    for s in ["(Game Preview)", "(PC)", "(Xbox Series X|S)", "(Xbox One)"]:
        n = n.replace(s, "")
    return n.strip()

# ---------- Wikidata enrichment (укр/англ), без платформ ----------
def wikidata_search_qid(name: str) -> Optional[str]:
    cache_path = wd_name_cache_path(name)
    cached = read_json(cache_path)
    if isinstance(cached, dict) and cached.get("name") == name and cached.get("qid") and cached.get("_schema")==CACHE_SCHEMA_VERSION:
        return str(cached["qid"])

    params = {
        "action": "wbsearchentities",
        "search": name,
        "language": "en",
        "format": "json",
        "limit": "5",
        "uselang": "en",
        "type": "item",
    }
    url = "https://www.wikidata.org/w/api.php?" + urllib.parse.urlencode(params)
    data = http_get_json(url)

    qid = None
    if isinstance(data, dict) and isinstance(data.get("search"), list) and data["search"]:
        first = data["search"][0]
        if isinstance(first, dict) and first.get("id"):
            qid = str(first["id"])

    write_json_atomic(cache_path, {"_schema": CACHE_SCHEMA_VERSION, "name": name, "qid": qid, "cached_at": datetime.now().isoformat()})
    return qid

def sparql_query(q: str) -> Any:
    url = "https://query.wikidata.org/sparql?" + urllib.parse.urlencode({"format": "json", "query": q})
    return http_get_json(url, headers={"Accept": "application/sparql-results+json"})

def _first_val(b: dict, key: str) -> str:
    return str((b.get(key, {}) or {}).get("value", "") or "")

def wikidata_enrich(qid: str) -> dict:
    cache_path = wd_qid_cache_path(qid)
    cached = read_json(cache_path)
    if isinstance(cached, dict) and cached.get("qid") == qid and isinstance(cached.get("data"), dict) and cached.get("_schema")==CACHE_SCHEMA_VERSION:
        return cached["data"]

    # Беремо жанри та описи укр/англ. Рейтинг — P444. Wikipedia — enwiki (як мінімум).
    query = f"""
    SELECT ?item
           ?desc_uk ?desc_en
           (GROUP_CONCAT(DISTINCT ?genreLabel_uk; separator=", ") AS ?genres_uk)
           (GROUP_CONCAT(DISTINCT ?genreLabel_en; separator=", ") AS ?genres_en)
           (MIN(?pubDate) AS ?pubDateMin)
           ?score ?reviewerLabel
           ?wikipedia
    WHERE {{
      BIND(wd:{qid} AS ?item)

      OPTIONAL {{ ?item schema:description ?desc_uk FILTER(LANG(?desc_uk)="uk") }}
      OPTIONAL {{ ?item schema:description ?desc_en FILTER(LANG(?desc_en)="en") }}

      OPTIONAL {{
        ?item wdt:P136 ?genre .
        OPTIONAL {{ ?genre rdfs:label ?genreLabel_uk FILTER(LANG(?genreLabel_uk)="uk") }}
        OPTIONAL {{ ?genre rdfs:label ?genreLabel_en FILTER(LANG(?genreLabel_en)="en") }}
      }}

      OPTIONAL {{ ?item wdt:P577 ?pubDate . }}

      OPTIONAL {{
        ?item p:P444 ?scoreStmt .
        ?scoreStmt ps:P444 ?score .
        OPTIONAL {{ ?scoreStmt pq:P447 ?reviewer . }}
      }}

      OPTIONAL {{
        ?wikipedia schema:about ?item ;
                   schema:isPartOf <https://en.wikipedia.org/> .
      }}

      SERVICE wikibase:label {{
        bd:serviceParam wikibase:language "uk,en".
        ?reviewer rdfs:label ?reviewerLabel .
      }}
    }}
    GROUP BY ?item ?desc_uk ?desc_en ?score ?reviewerLabel ?wikipedia
    """
    data = sparql_query(query)
    rows = data.get("results", {}).get("bindings", []) if isinstance(data, dict) else []

    genres_uk = ""
    genres_en = ""
    desc_uk = ""
    desc_en = ""
    wikipedia = ""
    year = ""
    score_best = ""
    reviewer_best = ""

    candidates = []
    for r in rows:
        candidates.append({
            "genres_uk": _first_val(r, "genres_uk"),
            "genres_en": _first_val(r, "genres_en"),
            "desc_uk": _first_val(r, "desc_uk"),
            "desc_en": _first_val(r, "desc_en"),
            "wikipedia": _first_val(r, "wikipedia"),
            "pub": _first_val(r, "pubDateMin"),
            "score": _first_val(r, "score"),
            "reviewer": _first_val(r, "reviewerLabel"),
        })

    for c in candidates:
        if not genres_uk and c["genres_uk"]:
            genres_uk = c["genres_uk"]
        if not genres_en and c["genres_en"]:
            genres_en = c["genres_en"]
        if not desc_uk and c["desc_uk"]:
            desc_uk = c["desc_uk"]
        if not desc_en and c["desc_en"]:
            desc_en = c["desc_en"]
        if not wikipedia and c["wikipedia"]:
            wikipedia = c["wikipedia"]
        if not year and c["pub"]:
            year = normalize_year(c["pub"])

    # Вибір рейтингу: якщо є Metacritic — пріоритет, інакше перший
    metacritic = [c for c in candidates if ("metacritic" in (c["reviewer"] or "").lower()) and c["score"]]
    if metacritic:
        score_best = metacritic[0]["score"]
        reviewer_best = metacritic[0]["reviewer"] or "Metacritic"
    else:
        anyscore = [c for c in candidates if c["score"]]
        if anyscore:
            score_best = anyscore[0]["score"]
            reviewer_best = anyscore[0]["reviewer"] or "Рейтинг"

    out = {
        "Genres_UK": normalize_genres(genres_uk),
        "Genres_EN": normalize_genres(genres_en),
        "Description_UK": (desc_uk or "").strip(),
        "Description_EN": (desc_en or "").strip(),
        "Year_WD": normalize_year(year),
        "Rating": normalize_rating(score_best),
        "RatingSource": (reviewer_best or "").strip(),
        "WikipediaUrl": (wikipedia or "").strip(),
        "WikidataUrl": f"https://www.wikidata.org/wiki/{qid}",
    }
    write_json_atomic(cache_path, {"_schema": CACHE_SCHEMA_VERSION, "qid": qid, "data": out, "cached_at": datetime.now().isoformat()})
    return out

# ---------- Hours via HowLongToBeat (optional) ----------
def get_hours_hltb(name: str) -> str:
    cache_path = hltb_name_cache_path(name)
    cached = read_json(cache_path)
    if isinstance(cached, dict) and cached.get("name") == name and "hours" in cached and cached.get("_schema")==CACHE_SCHEMA_VERSION:
        return str(cached.get("hours") or "")

    if not ARGS.hltb:
        return ""

    try:
        from howlongtobeatpy import HowLongToBeat  # type: ignore
    except Exception:
        return ""

    hours = ""
    try:
        results = HowLongToBeat().search(name)
        if results:
            best = results[0]
            h = getattr(best, "main_story", None)
            if h:
                hours = str(h)
            else:
                h2 = getattr(best, "main_extra", None)
                if h2:
                    hours = str(h2)
    except Exception:
        hours = ""

    write_json_atomic(cache_path, {"_schema": CACHE_SCHEMA_VERSION, "name": name, "hours": hours, "cached_at": datetime.now().isoformat()})
    return hours

# ---------- HTML ----------
HTML_TEMPLATE = """<!doctype html>
<html lang="uk">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>__TITLE__</title>
  <style>
    :root{
      --bg:#f5f5f7;
      --panel:#ffffff;
      --border:#d2d2d7;
      --text:#1d1d1f;
      --muted:#6e6e73;
      --hover:#f0f0f3;
      --accent:#0a84ff;
      --radius:12px;
      --shadow:0 1px 0 rgba(0,0,0,.04);
      --row:56px;
      --font:-apple-system,BlinkMacSystemFont,"SF Pro Text","SF Pro Display","Segoe UI",Roboto,Ubuntu,Helvetica,Arial,sans-serif;
    }
    *{box-sizing:border-box}
    html,body{height:100%}
    body{margin:0;background:var(--bg);color:var(--text);font-family:var(--font);-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale}
    header{
      padding:14px 16px;
      display:flex;align-items:center;gap:12px;flex-wrap:wrap;
    }
    .title{font-weight:700;font-size:16px}
    .sub{color:var(--muted);font-size:12px}
    .app{
      display:grid;
      grid-template-columns:280px 1fr;
      gap:12px;
      padding:12px;
      max-width:1400px;
      margin:0 auto;
    }
    .panel{
      background:var(--panel);
      border:1px solid var(--border);
      border-radius:var(--radius);
      box-shadow:var(--shadow);
    }
    aside{
      padding:12px;
      position:sticky;
      top:12px;
      height:calc(100vh - 24px);
      overflow:auto;
    }
    .section{margin:10px 0 14px}
    .section h3{margin:0 0 8px;font-size:12px;letter-spacing:.08em;color:var(--muted);text-transform:uppercase}
    label{display:block;font-size:13px;margin:8px 0}
    select,input[type="text"]{
      width:100%;
      padding:8px 10px;
      border:1px solid var(--border);
      border-radius:10px;
      background:#fff;
      font-size:13px;
      outline:none;
    }
    select:focus,input[type="text"]:focus{border-color:rgba(10,132,255,.6);box-shadow:0 0 0 3px rgba(10,132,255,.15)}
    .row{display:flex;gap:10px;align-items:center}
    .row > *{flex:1}
    .check{display:flex;align-items:center;gap:8px;font-size:13px;color:var(--text);margin:10px 0}
    .check input{width:16px;height:16px}
    .btn{
      display:inline-flex;align-items:center;justify-content:center;
      padding:8px 10px;
      border:1px solid var(--border);
      border-radius:10px;
      background:#fff;
      font-size:13px;
      cursor:pointer;
    }
    .btn:hover{background:var(--hover)}
    .btn.primary{border-color:rgba(10,132,255,.35);background:rgba(10,132,255,.08)}
    .stats{color:var(--muted);font-size:12px;margin-top:6px}
    main{overflow:hidden}
    .table-wrap{overflow:auto}
    table{width:100%;border-collapse:collapse;table-layout:fixed}
    thead{background:#fafafa;border-bottom:1px solid var(--border)}
    th,td{
      padding:10px 10px;
      font-size:13px;
      white-space:nowrap;
      overflow:hidden;
      text-overflow:ellipsis;
      border-bottom:1px solid rgba(0,0,0,.06);
      height:var(--row);
      vertical-align:middle;
    }
    th{color:var(--muted);font-weight:600}
    tbody tr:hover{background:var(--hover)}
    .col-star{width:34px}
    .col-cover{width:56px}
    .col-year{width:70px}
    .col-rating{width:92px}
    .col-hours{width:86px}
    .col-info{width:44px}
    .cover{
      width:40px;height:40px;border-radius:8px;object-fit:cover;display:block;
      background:rgba(0,0,0,.06);
    }
    .star{
      cursor:pointer;
      font-size:16px;
      line-height:1;
      color:#c7c7cc;
      user-select:none;
    }
    .star.on{color:#ffcc00}
    .name{font-weight:600}
    .muted{color:var(--muted)}
    .pill{
      display:inline-flex;align-items:center;gap:6px;
      padding:4px 8px;border:1px solid rgba(0,0,0,.10);
      border-radius:999px;font-size:12px;color:var(--muted);background:#fff;
    }
    .info-btn{
      width:28px;height:28px;border-radius:8px;border:1px solid var(--border);
      background:#fff;cursor:pointer;
    }
    .info-btn:hover{background:var(--hover)}
    /* Modal */
    .modal{
      position:fixed;inset:0;display:none;align-items:center;justify-content:center;
      background:rgba(0,0,0,.38);
      padding:16px;
    }
    .modal.open{display:flex}
    .modal .box{
      width:760px;max-width:100%;
      background:#fff;border-radius:16px;
      border:1px solid rgba(0,0,0,.12);
      box-shadow:0 20px 50px rgba(0,0,0,.25);
      overflow:hidden;
    }
    .modal .box header{
      padding:14px 16px;
      border-bottom:1px solid rgba(0,0,0,.08);
      display:flex;align-items:flex-start;justify-content:space-between;gap:12px;
      background:#fafafa;
    }
    .modal h2{margin:0;font-size:18px}
    .modal .content{padding:14px 16px;display:grid;grid-template-columns:120px 1fr;gap:14px}
    .modal .content img{width:120px;height:120px;border-radius:14px;object-fit:cover;background:rgba(0,0,0,.06)}
    .kv{display:grid;grid-template-columns:120px 1fr;gap:8px 10px;font-size:13px}
    .kv .k{color:var(--muted)}
    .desc{margin-top:10px;font-size:13px;line-height:1.45;white-space:pre-wrap}
    .links a{color:var(--accent)}
    .x{border:0;background:transparent;cursor:pointer;font-size:20px;line-height:1;color:var(--muted)}
    @media (max-width: 980px){
      .app{grid-template-columns:1fr}
      aside{position:relative;height:auto}
      .modal .content{grid-template-columns:1fr}
    }
  </style>
</head>
<body>
<header>
  <div>
    <div class="title">Каталог Game Pass</div>
    <div class="sub">Оновлено: <span id="updatedAt"></span></div>
  </div>
  <span class="pill" id="countPill">0 ігор</span>
</header>

<div class="app">
  <aside class="panel">
    <div class="section">
      <h3>Пошук</h3>
      <input id="q" type="text" placeholder="Назва, видавець, розробник…">
    </div>

    <div class="section">
      <h3>Фільтри</h3>
      <label>Рік
        <select id="fy"><option value="">Усі</option></select>
      </label>
      <label>Жанр
        <select id="fg"><option value="">Усі</option></select>
      </label>
      <label>Рейтинг
        <select id="fr"><option value="">Усі</option></select>
      </label>
      <div class="check">
        <input id="ff" type="checkbox">
        <label for="ff" style="margin:0">Тільки обране ★</label>
      </div>
      <div class="row">
        <button class="btn" id="reset">Скинути</button>
        <button class="btn primary" id="copyCsv">Скопіювати CSV</button>
      </div>
      <div class="stats" id="stats"></div>
    </div>
  </aside>

  <main class="panel">
    <div class="table-wrap">
      <table>
        <thead>
          <tr>
            <th class="col-star">★</th>
            <th class="col-cover"></th>
            <th>Назва</th>
            <th>Жанр</th>
            <th class="col-year">Рік</th>
            <th>Видавець</th>
            <th class="col-rating">Рейтинг</th>
            <th class="col-hours">Год.</th>
            <th class="col-info"></th>
          </tr>
        </thead>
        <tbody id="tb"></tbody>
      </table>
    </div>
  </main>
</div>

<div class="modal" id="modal" role="dialog" aria-modal="true">
  <div class="box">
    <header>
      <div>
        <h2 id="mt"></h2>
        <div class="sub" id="msub"></div>
      </div>
      <button class="x" id="mx" aria-label="Закрити">×</button>
    </header>
    <div class="content">
      <img id="mi" alt="">
      <div>
        <div class="kv" id="mkv"></div>
        <div class="desc" id="md"></div>
        <div class="desc links" id="ml"></div>
      </div>
    </div>
  </div>
</div>

<script>
const DATA = __DATA_JSON__;
const UPDATED_AT = (DATA && DATA.length && DATA[0] && DATA[0]._updated_at) ? DATA[0]._updated_at : "";
document.getElementById("updatedAt").textContent = UPDATED_AT || "—";

const tb = document.getElementById("tb");
const fy = document.getElementById("fy");
const fg = document.getElementById("fg");
const fr = document.getElementById("fr");
const ff = document.getElementById("ff");
const q  = document.getElementById("q");
const stats = document.getElementById("stats");
const countPill = document.getElementById("countPill");

const FAV_KEY="gp_favs_v1";
const favs = new Set(JSON.parse(localStorage.getItem(FAV_KEY) || "[]"));

function esc(s){return String(s??"").replace(/[&<>"]/g,m=>({ "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;" }[m]))}

function splitGenres(s){
  return String(s||"").split(",").map(x=>x.trim()).filter(Boolean);
}

function initFilters(){
  const years = [...new Set(DATA.map(x=>x.year).filter(Boolean))].sort();
  const genres = [...new Set(DATA.flatMap(x=>splitGenres(x.genre)))].sort((a,b)=>a.localeCompare(b,'uk'));
  const ratings = [...new Set(DATA.map(x=>x.rating).filter(Boolean))].sort((a,b)=>a.localeCompare(b,'uk'));

  for(const y of years) fy.insertAdjacentHTML("beforeend", `<option value="${esc(y)}">${esc(y)}</option>`);
  for(const g of genres) fg.insertAdjacentHTML("beforeend", `<option value="${esc(g)}">${esc(g)}</option>`);
  for(const r of ratings) fr.insertAdjacentHTML("beforeend", `<option value="${esc(r)}">${esc(r)}</option>`);
}

function isFav(id){ return favs.has(id); }
function toggleFav(id){
  if(favs.has(id)) favs.delete(id); else favs.add(id);
  localStorage.setItem(FAV_KEY, JSON.stringify([...favs]));
}

function rowHtml(x){
  const starCls = isFav(x.id) ? "star on" : "star";
  const starSym = isFav(x.id) ? "★" : "☆";
  const img = x.image ? `<img class="cover" loading="lazy" src="${esc(x.image)}" alt="">` : `<div class="cover"></div>`;
  const genre = esc(x.genre||"");
  const year = esc(x.year||"");
  const pub = esc(x.publisher||"");
  const rating = esc(x.rating||"");
  const hours = esc(x.hours||"");
  return `<tr data-id="${esc(x.id)}">
    <td class="col-star"><span class="${starCls}" data-action="fav">${starSym}</span></td>
    <td class="col-cover">${img}</td>
    <td title="${esc(x.name)}"><span class="name">${esc(x.name)}</span></td>
    <td title="${genre}">${genre}</td>
    <td class="col-year">${year}</td>
    <td title="${pub}">${pub}</td>
    <td class="col-rating">${rating}</td>
    <td class="col-hours">${hours}</td>
    <td class="col-info"><button class="info-btn" data-action="info" title="Деталі">ℹ</button></td>
  </tr>`;
}

function apply(){
  const y = fy.value;
  const g = fg.value;
  const r = fr.value;
  const onlyFav = ff.checked;
  const query = q.value.trim().toLowerCase();

  let list = DATA;

  if(y) list = list.filter(x => String(x.year||"") === y);
  if(g) list = list.filter(x => splitGenres(x.genre).includes(g));
  if(r) list = list.filter(x => String(x.rating||"") === r);
  if(onlyFav) list = list.filter(x => favs.has(x.id));
  if(query){
    list = list.filter(x => {
      const hay = `${x.name||""} ${x.publisher||""} ${x.developer||""}`.toLowerCase();
      return hay.includes(query);
    });
  }

  tb.innerHTML = list.map(rowHtml).join("");
  countPill.textContent = `${list.length} ігор`;
  stats.textContent = `Усього у DATA: ${DATA.length} • Показано: ${list.length}`;
}

function openModal(x){
  document.getElementById("mt").textContent = x.name || "";
  document.getElementById("msub").textContent = [x.genre, x.year].filter(Boolean).join(" • ");
  const mi = document.getElementById("mi");
  mi.src = x.image || "";
  mi.alt = x.name || "";

  const kv = [];
  if(x.publisher) kv.push(["Видавець", x.publisher]);
  if(x.developer) kv.push(["Розробник", x.developer]);
  if(x.rating) kv.push(["Рейтинг", x.rating + (x.ratingSource ? ` (${x.ratingSource})` : "")]);
  if(x.hours) kv.push(["Години", x.hours]);

  document.getElementById("mkv").innerHTML = kv.map(([k,v])=>`<div class="k">${esc(k)}</div><div>${esc(v)}</div>`).join("");
  document.getElementById("md").textContent = x.description || "";

  const links = [];
  if(x.wikipedia) links.push(`<a target="_blank" rel="noopener" href="${esc(x.wikipedia)}">Wikipedia</a>`);
  if(x.wikidata) links.push(`<a target="_blank" rel="noopener" href="${esc(x.wikidata)}">Wikidata</a>`);
  document.getElementById("ml").innerHTML = links.length ? ("Посилання: " + links.join(" • ")) : "";

  document.getElementById("modal").classList.add("open");
}

function closeModal(){ document.getElementById("modal").classList.remove("open"); }

tb.addEventListener("click", (e)=>{
  const tr = e.target.closest("tr");
  if(!tr) return;
  const id = tr.getAttribute("data-id");
  const x = DATA.find(z => z.id === id);
  if(!x) return;

  const actionEl = e.target.closest("[data-action]");
  const action = actionEl ? actionEl.getAttribute("data-action") : "";

  if(action === "fav"){
    toggleFav(id);
    apply();
    return;
  }
  if(action === "info"){
    openModal(x);
    return;
  }
  // клік по рядку -> деталі
  openModal(x);
});

document.getElementById("mx").addEventListener("click", closeModal);
document.getElementById("modal").addEventListener("click", (e)=>{ if(e.target.id==="modal") closeModal(); });
document.addEventListener("keydown", (e)=>{ if(e.key==="Escape") closeModal(); });

document.getElementById("reset").addEventListener("click", ()=>{
  fy.value=""; fg.value=""; fr.value=""; ff.checked=false; q.value="";
  apply();
});

document.getElementById("copyCsv").addEventListener("click", async ()=>{
  // Копіюємо поточний CSV з таблиці (ID, Name, Genre, Year, Publisher, Rating, Hours)
  const rows = Array.from(tb.querySelectorAll("tr")).map(tr=>{
    const tds = tr.querySelectorAll("td");
    const id = tr.getAttribute("data-id")||"";
    const name = tds[2]?.innerText||"";
    const genre = tds[3]?.innerText||"";
    const year = tds[4]?.innerText||"";
    const pub = tds[5]?.innerText||"";
    const rating = tds[6]?.innerText||"";
    const hours = tds[7]?.innerText||"";
    return [id,name,genre,year,pub,rating,hours].map(v=> `"${String(v).replace(/"/g,'""')}"`).join(",");
  });
  const csv = ["id,name,genre,year,publisher,rating,hours"].concat(rows).join("\n");
  try{ await navigator.clipboard.writeText(csv); }
  catch(_){ /* ignore */ }
});

[fy,fg,fr,ff].forEach(el=>el.addEventListener("change", apply));
q.addEventListener("input", ()=>{ window.clearTimeout(q._t); q._t = window.setTimeout(apply, 120); });

initFilters();
apply();
</script>
</body>
</html>
"""


def build_html(rows: List[dict]) -> str:
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    title = f"Каталог Game Pass ({MARKET}) — {now}"
    data_json = json.dumps(rows, ensure_ascii=False)
    out = HTML_TEMPLATE.replace("__TITLE__", html.escape(title))
    out = out.replace("__DATA_JSON__", data_json)
    return out

def save_outputs(rows: List[dict]):
    rows.sort(key=lambda x: (x.get("name") or "").lower())

    cols = ["id","name","genre","description","rating","ratingSource","year","hours","publisher","developer","wikipedia","wikidata","image"]
    with open(OUT_CSV, "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=cols)
        w.writeheader()
        for r in rows:
            w.writerow({k: r.get(k,"") for k in cols})

    with open(OUT_HTML, "w", encoding="utf-8") as f:
        f.write(build_html(rows))

    print(f"Збережено: {OUT_HTML}")
    print(f"Збережено: {OUT_CSV}")
    print(f"Кеш: {CACHE_DIR}")

# ---------- Main ----------
def main():
    ensure_dirs()

    if prompt_resume_or_reset() == "reset":
        reset_cache()

    # SIGL
    sigl_cache = read_json(SIGL_FILE)
    if (
        isinstance(sigl_cache, dict)
        and isinstance(sigl_cache.get("ids"), list)
        and sigl_cache.get("_schema")==CACHE_SCHEMA_VERSION
        and sigl_cache.get("market")==MARKET
        and sigl_cache.get("data_lang")==DATA_LANG
    ):
        ids = [str(x) for x in sigl_cache["ids"]]
        print(f"З кешу завантажено SIGL id: {len(ids)}")
    else:
        print(f"Отримую список ігор (SIGL)… market={MARKET} мова={DATA_LANG}")
        ids = get_sigl_ids(SIGL_ALL)
        write_json_atomic(SIGL_FILE, {
            "_schema": CACHE_SCHEMA_VERSION,
            "market": MARKET,
            "data_lang": DATA_LANG,
            "sigl": SIGL_ALL,
            "ids": ids
        })
        print(f"Отримано ігор: {len(ids)}")
    # --- render-only: no network, only cached outputs ---
    if getattr(ARGS, "render_only", False):
        rows: List[dict] = []
        missing = 0
        for bid in ids:
            prod = load_product_from_cache(bid)
            if not prod:
                missing += 1
                continue
            store = extract_store_fields(prod)
            name = (store.get("Name","") or "").strip()
            if not name:
                missing += 1
                continue
            rows.append({
                "id": bid,
                "name": name,
                "genre": normalize_genres(store.get("StoreGenres","") or ""),
                "description": (store.get("ShortDescription","") or "").strip(),
                "rating": "",
                "ratingSource": "",
                "year": normalize_year(store.get("StoreYear","")),
                "hours": "",
                "publisher": (store.get("Publisher","") or "").strip(),
                "developer": (store.get("Developer","") or "").strip(),
                "wikipedia": "",
                "wikidata": "",
                "image": store.get("ImageUrl",""),
            })
        save_outputs(rows)
        print(f"Render-only: згенеровано {len(rows)} записів (пропущено {missing}).")
        return


    # План Store fetch
    to_fetch = []
    cached_ok = 0
    for bid in ids:
        if load_product_from_cache(bid):
            cached_ok += 1
        else:
            to_fetch.append(bid)

    print(f"Усього: {len(ids)} | У кеші: {cached_ok} | Треба завантажити: {len(to_fetch)}")

    if len(to_fetch) == 0:
        set_phase("store", 0)
        print("[МАГАЗИН] Кеш повний. Завантажувати нічого не потрібно.")
                # Якщо нічого не треба завантажувати — все одно будуємо rows з кешу для HTML/CSV.
        rows: List[dict] = []
        missing = 0
        for bid in ids:
            cached = load_product_from_cache(bid)
            if not isinstance(cached, dict):
                missing += 1
                continue
            prod = cached.get("product") if isinstance(cached.get("product"), dict) else cached
            store = extract_store_fields(prod)
            name = (store.get("Name","") or "").strip()
            if not name:
                missing += 1
                continue
            rows.append({
                "id": bid,
                "name": name,
                "genre": normalize_genres(store.get("StoreGenres","") or ""),
                "description": (store.get("ShortDescription","") or "").strip(),
                "rating": "",
                "ratingSource": "",
                "year": normalize_year(store.get("StoreYear","")),
                "hours": "",
                "publisher": (store.get("Publisher","") or "").strip(),
                "developer": (store.get("Developer","") or "").strip(),
                "wikipedia": "",
                "wikidata": "",
                "image": store.get("ImageUrl",""),
            })
        if rows:
            save_outputs(rows)
        else:
            print(f"УВАГА: rows порожній (missing={missing}). Перевір кеш products/*.json та extract_store_fields().")
        return
        heartbeat(force=True)
    else:
        set_phase("store", total=len(to_fetch))
        pbar = tqdm(total=len(to_fetch), desc="Store: завантаження", unit="шт") if tqdm else None

        def progress_cb(n:int):
            phase_step(n)
            if pbar:
                pbar.update(n)

        remaining = to_fetch[:]
        while remaining:
            chunk = remaining[:PASS_SIZE]
            remaining = remaining[len(chunk):]
            fetch_products_reliably(chunk, INITIAL_BATCH_SIZE, progress_cb=progress_cb)
            heartbeat()
            time.sleep(SLEEP_BETWEEN_REQUESTS_SEC)

        if pbar:
            pbar.close()
        if IS_TTY:
            print()
        if sys.stdout.isatty():
            print()

    # Enrichment resume
    state = read_json(STATE_FILE)
    enrich_start = 0
    if isinstance(state, dict) and state.get("_schema")==CACHE_SCHEMA_VERSION and isinstance(state.get("enrich_index"), int):
        enrich_start = int(state["enrich_index"])
        if enrich_start < 0 or enrich_start >= len(ids):
            enrich_start = 0

    
    generate_only = False
    # Якщо enrichment уже пройдений (enrich_index дорівнює кількості ids), то повторний запуск
    # може створити порожній HTML/CSV (бо цикл не виконається). У цьому випадку згенеруємо
    # звіти з кешу Store без Wikidata/HLTB, щоб не отримати 'нуль дата'.
    if enrich_start >= len(ids) and len(ids) > 0:
        generate_only = True
        enrich_start = len(ids)
        print(f"Enrich вже завершено ({len(ids)}/{len(ids)}). Генерую HTML/CSV з кешу Store…")
    if enrich_start > 0 and enrich_start < len(ids):
        print(f"Продовжую деталей з позиції: {enrich_start}/{len(ids)}")

    set_phase("enrich", total=max(0, len(ids) - enrich_start))
    ebar = tqdm(total=max(0, len(ids) - enrich_start), desc="Деталі", unit="гра") if (tqdm and enrich_start < len(ids)) else None

    rows: List[dict] = []

    if generate_only:
        # Побудова рядків лише з кешу Store (без зовнішніх запитів)
        for bid in ids:
            prod = load_product_from_cache(bid)
            if not prod:
                continue
            store = extract_store_fields(prod)
            name = store.get("Name","")
            if not name:
                continue
            rows.append({
                "id": bid,
                "name": name,
                "genre": normalize_genres(store.get("StoreGenres","")),
                "description": (store.get("ShortDescription","") or "").strip(),
                "rating": "",
                "ratingSource": "",
                "year": normalize_year(store.get("StoreYear","")),
                "hours": "",
                "publisher": (store.get("Publisher","") or "").strip(),
                "developer": (store.get("Developer","") or "").strip(),
                "wikipedia": "",
                "wikidata": "",
                "image": store.get("ImageUrl",""),
            })
        save_outputs(rows)
        return
    for idx in range(enrich_start, len(ids)):
        bid = ids[idx]
        write_json_atomic(STATE_FILE, {"_schema": CACHE_SCHEMA_VERSION, "enrich_index": idx})

        prod = load_product_from_cache(bid)
        if not prod:
            phase_step(1)
            if ebar: ebar.update(1)
            continue

        store = extract_store_fields(prod)
        name = store.get("Name","")
        if not name:
            phase_step(1)
            if ebar: ebar.update(1)
            continue

        wd = {
            "Genres_UK":"", "Genres_EN":"",
            "Description_UK":"", "Description_EN":"",
            "Year_WD":"", "Rating":"", "RatingSource":"",
            "WikipediaUrl":"", "WikidataUrl":""
        }
        if not ARGS.no_wikidata:
            try:
                qid = wikidata_search_qid(clean_title_for_search(name))
                if qid:
                    wd = wikidata_enrich(qid)
            except Exception as e:
                warn(f"  ! Wikidata: не вдалося для '{name}': {e}")

        year = normalize_year(wd.get("Year_WD","")) or store.get("StoreYear","")

        # Жанр/опис: uk -> en -> пусто
        genre = normalize_genres(wd.get("Genres_UK","")) or normalize_genres(wd.get("Genres_EN","")) or normalize_genres(store.get("StoreGenres",""))
        desc = (wd.get("Description_UK","") or "").strip() or (wd.get("Description_EN","") or "").strip() or store.get("ShortDescription","")

        rating = normalize_rating(wd.get("Rating",""))
        rating_source = (wd.get("RatingSource","") or "").strip()
        wiki = (wd.get("WikipediaUrl","") or "").strip()
        wdu = (wd.get("WikidataUrl","") or "").strip()

        hours = ""
        try:
            hours = get_hours_hltb(clean_title_for_search(name))
        except Exception:
            hours = ""

        rows.append({
            "id": bid,
            "name": name,
            "genre": genre,
            "description": desc,
            "rating": rating,
            "ratingSource": rating_source,
            "year": year,
            "hours": hours,
            "publisher": store.get("Publisher",""),
            "developer": store.get("Developer",""),
            "wikipedia": wiki,
            "wikidata": wdu,
            "image": store.get("ImageUrl",""),
        })

        phase_step(1, item=name)
        if ebar:
            ebar.update(1)
        else:
            heartbeat()
        time.sleep(SLEEP_BETWEEN_REQUESTS_SEC)

    if ebar:
        ebar.close()
    if IS_TTY:
        print()
    if sys.stdout.isatty():
        print()

    write_json_atomic(STATE_FILE, {"_schema": CACHE_SCHEMA_VERSION, "enrich_index": len(ids)})
    save_outputs(rows)
    print("Готово ✅")

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        if IS_TTY:
            try:
                width = shutil.get_terminal_size(fallback=(120, 20)).columns
                sys.stdout.write("\r" + (" " * width) + "\r")
                sys.stdout.flush()
            except Exception:
                pass
            print()
        print("\nЗупинено. Прогрес збережено в кеші. Запусти ще раз, щоб продовжити.")
        sys.exit(1)
