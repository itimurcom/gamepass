(function () {
  "use strict";

  const $ = (id) => document.getElementById(id);

  const state = {
    lang: "EN",
    theme: "light",
    view: "table",
    q: "",
    sortKey: "name",
    sortDir: "asc",
    page: 1,
    pageSize: 48,
    pageSizeTable: 48,
    pageSizeTiles: 50,
    listKey: "pcgaVTaz",
  };

  function safeText(v) {
    return (v === null || v === undefined) ? "" : String(v);
  }

  function getData() {
    return window.GAMEPASS_DATA || { products: { EN: {}, UA: {} }, lists: { EN: {}, UA: {} } };
  }

  function getProducts() {
    const d = getData();
    return (d.products && d.products[state.lang]) ? d.products[state.lang] : {};
  }

  function getLists() {
    const d = getData();
    return (d.lists && d.lists[state.lang]) ? d.lists[state.lang] : {};
  }

  function firstLocalized(product) {
    const lp = product && product.LocalizedProperties;
    if (Array.isArray(lp) && lp.length > 0 && typeof lp[0] === "object" && lp[0]) return lp[0];
    return null;
  }

  function getTitle(product, gameid) {
    const lp = firstLocalized(product);
    return safeText((lp && (lp.ProductTitle || lp.Title)) || product.ProductTitle || gameid);
  }

  function getPublisher(product) {
    const p = product || {};
    const props = p.Properties || {};
    const mp = Array.isArray(p.MarketProperties) ? p.MarketProperties[0] : null;
    const lp = firstLocalized(p) || {};
    return safeText(
      p.PublisherName ||
      p.Publisher ||
      props.PublisherName ||
      props.Publisher ||
      (mp && (mp.PublisherName || mp.Publisher)) ||
      lp.PublisherName ||
      lp.Publisher ||
      ""
    );
  }

  function getDeveloper(product) {
    const p = product || {};
    const props = p.Properties || {};
    const mp = Array.isArray(p.MarketProperties) ? p.MarketProperties[0] : null;
    const lp = firstLocalized(p) || {};
    return safeText(
      p.DeveloperName ||
      p.Developer ||
      props.DeveloperName ||
      props.Developer ||
      (mp && (mp.DeveloperName || mp.Developer)) ||
      lp.DeveloperName ||
      lp.Developer ||
      ""
    );
  }

  function extractStringList(v) {
    if (!v) return [];
    if (Array.isArray(v)) {
      const out = [];
      for (const it of v) {
        if (!it) continue;
        if (typeof it === "string") {
          const s = safeText(it).trim();
          if (s) out.push(s);
          continue;
        }
        if (typeof it === "object") {
          const s = safeText(it.Name || it.DisplayName || it.Value || it.Id || "").trim();
          if (s) out.push(s);
        }
      }
      return out;
    }
    if (typeof v === "string") return [safeText(v).trim()].filter(Boolean);
    return [];
  }

  function uniq(arr) {
    const out = [];
    const seen = new Set();
    for (const x of arr) {
      const s = safeText(x).trim();
      if (!s) continue;
      const k = s.toLowerCase();
      if (seen.has(k)) continue;
      seen.add(k);
      out.push(s);
    }
    return out;
  }

  function getGenres(product) {
    const p = product || {};
    const props = p.Properties || {};
    const mp = Array.isArray(p.MarketProperties) ? p.MarketProperties[0] : null;
    const lp = firstLocalized(p) || {};

    const candidates = [
      props.Genres, p.Genres, lp.Genres,
      props.Categories, p.Categories, lp.Categories,
      props.Genre, p.Genre, lp.Genre,
      props.Category, p.Category, lp.Category,
      mp && (mp.Genres || mp.Categories || mp.Genre || mp.Category),
    ];

    let all = [];
    for (const c of candidates) all = all.concat(extractStringList(c));
    return uniq(all);
  }

  function getGenresText(product) {
    return getGenres(product).join(", ");
  }
  function getReleaseDateRaw(product) {
    const mp = product && product.MarketProperties;
    const d = (Array.isArray(mp) && mp[0] && mp[0].OriginalReleaseDate) ? mp[0].OriginalReleaseDate : (product.OriginalReleaseDate || "");
    return safeText(d || "");
  }

  function getReleaseYear(product) {
    // Microsoft sometimes returns sentinel dates like 9998/9999 when release date is unknown.
    // Prefer a "realistic" year; otherwise return empty string.
    const mp = product && product.MarketProperties;
    const lp = firstLocalized(product);

    const candidates = [
      getReleaseDateRaw(product),
      (Array.isArray(mp) && mp[0] && (mp[0].OriginalReleaseDateUtc || mp[0].ReleaseDate || mp[0].FirstAvailableDate)) || "",
      (product && (product.OriginalReleaseDateUtc || product.ReleaseDate || product.FirstAvailableDate)) || "",
      (lp && (lp.OriginalReleaseDate || lp.OriginalReleaseDateUtc || lp.ReleaseDate)) || "",
    ];

    const maxYear = (new Date()).getFullYear() + 1;
    for (const raw0 of candidates) {
      const raw = safeText(raw0 || "");
      if (!raw) continue;
      const m = raw.match(/^\d{4}/);
      if (!m) continue;
      const y = parseInt(m[0], 10);
      if (!Number.isFinite(y)) continue;
      if (y >= 9000) continue;       // filters 9998/9999 sentinels
      if (y < 1970) continue;
      if (y > maxYear) continue;
      return m[0];
    }

  function getAddedDateRaw(product) {
    // "Added" approximation: use first-available/available dates where present.
    const lp = firstLocalized(product);
    const mp = product && product.MarketProperties;
    const props = product && product.Properties;

    const candidates = [
      (Array.isArray(mp) && mp[0] && (mp[0].FirstAvailableDate || mp[0].FirstAvailableDateUtc || mp[0].AvailableDate || mp[0].AvailableDateUtc)) || "",
      (product && (product.FirstAvailableDate || product.FirstAvailableDateUtc || product.AvailableDate || product.AvailableDateUtc)) || "",
      (props && (props.FirstAvailableDate || props.FirstAvailableDateUtc || props.AvailableDate || props.AvailableDateUtc)) || "",
      (lp && (lp.FirstAvailableDate || lp.FirstAvailableDateUtc || lp.AvailableDate || lp.AvailableDateUtc)) || "",
    ];

    for (const c of candidates) {
      const s = safeText(c || "");
      if (s) return s;
    }
    return "";
  }

  function formatIsoDateShort(raw) {
    const s = safeText(raw || "");
    if (!s) return "";
    if (s.length >= 10 && s[4] === "-" && s[7] === "-") return s.slice(0, 10);
    return s;
  }

  function getAddedDateDisplay(product) {
    const raw = getAddedDateRaw(product);
    if (!raw) return "";

    const m = raw.match(/^\d{4}/);
    if (!m) return "";
    const y = parseInt(m[0], 10);
    if (!Number.isFinite(y)) return "";

    const maxY = (new Date()).getFullYear() + 1;
    if (y >= 9000) return ""; // filters 9998/9999 sentinels
    if (y < 1970) return "";
    if (y > maxY) return "";

    return formatIsoDateShort(raw);
  }

    return "";
  }

  function getDescription(product) {
    const lp = firstLocalized(product);
    return safeText((lp && (lp.ProductDescription || lp.Description)) || "");
  }

  function pickImageUrl(product) {
    const lp = firstLocalized(product);
    const imgs = lp && lp.Images;
    if (!Array.isArray(imgs)) return "";

    const preferredPurposes = [
      "Poster",
      "BoxArt",
      "BrandedKeyArt",
      "SuperHeroArt",
      "Hero",
      "FeaturePromotionalSquareArt",
      "Screenshot",
      "Icon",
      "Logo",
    ];

    for (const purpose of preferredPurposes) {
      const hit = imgs.find((x) => x && x.ImagePurpose === purpose && x.Uri);
      if (hit) return hit.Uri;
    }

    const any = imgs.find((x) => x && x.Uri);
    return any ? any.Uri : "";
  }

  function matchesQuery(title, publisher, developer, genre, q) {
    if (!q) return true;
    const s = (title + " " + publisher + " " + developer + " " + genre).toLowerCase();
    return s.includes(q.toLowerCase());
  }

  function setTheme(theme) {
    state.theme = theme;
    document.documentElement.setAttribute("data-theme", theme === "dark" ? "dark" : "light");
    try { localStorage.setItem("gp_theme", theme); } catch (_) {}
  }

  function toggleTheme() {
    setTheme(state.theme === "dark" ? "light" : "dark");
  }

  function setLang(lang) {
    state.lang = lang;
    state.page = 1;
    $("btnLang").textContent = lang;
    try { localStorage.setItem("gp_lang", lang); } catch (_) {}
    populateLists();
    renderAll();
  }

  function toggleLang() {
    setLang(state.lang === "EN" ? "UA" : "EN");
  }

  function setView(view) {
    state.view = view;
    // Keep tile pages aligned to a full row (5 columns)
    state.pageSize = (view === "tiles") ? state.pageSizeTiles : state.pageSizeTable;
    state.page = 1;
    $("btnTable").classList.toggle("active", view === "table");
    $("btnTiles").classList.toggle("active", view === "tiles");
    $("tableView").style.display = (view === "table") ? "" : "none";
    $("tilesView").style.display = (view === "tiles") ? "" : "none";
    renderAll();
  }

  function setSort(key) {
    if (state.sortKey === key) {
      state.sortDir = (state.sortDir === "asc") ? "desc" : "asc";
    } else {
      state.sortKey = key;
      state.sortDir = "asc";
    }
    renderAll();
  }

  function getSelectedIdsSet() {
    const lists = getLists();
    const lst = lists[state.listKey];
    const items = lst && Array.isArray(lst.items) ? lst.items : null;
    if (!items) return null;
    const set = new Set();
    for (const id of items) if (typeof id === "string" && id) set.add(id);
    return set;
  }

  function getEntriesFilteredSorted() {
    const prods = getProducts();
    const entries = Object.entries(prods);

    const idsSet = getSelectedIdsSet();
    const out = [];
    for (const [gameid, product] of entries) {
      if (idsSet && !idsSet.has(gameid)) continue;

      const title = getTitle(product, gameid);
      const pub = getPublisher(product);
      const dev = getDeveloper(product);
      const genre = getGenresText(product);
      if (!matchesQuery(title, pub, dev, genre, state.q)) continue;

      out.push({
        gameid,
        product,
        title,
        pub,
        dev,
        genre,
        year: getReleaseYear(product),
        added: getAddedDateDisplay(product),
      });
    }

    const dir = state.sortDir === "asc" ? 1 : -1;
    out.sort((a, b) => {
      if (state.sortKey === "publisher") return a.pub.localeCompare(b.pub) * dir;
      if (state.sortKey === "developer") return a.dev.localeCompare(b.dev) * dir;
      if (state.sortKey === "genre") return a.genre.localeCompare(b.genre) * dir;
      if (state.sortKey === "year") return (a.year.localeCompare(b.year) || a.title.localeCompare(b.title)) * dir;
      if (state.sortKey === "added") return (a.added.localeCompare(b.added) || a.title.localeCompare(b.title)) * dir;
      return a.title.localeCompare(b.title) * dir;
    });

    return out;
  }

  function paginate(items) {
    const total = items.length;
    const pages = Math.max(1, Math.ceil(total / state.pageSize));
    if (state.page > pages) state.page = pages;

    const start = (state.page - 1) * state.pageSize;
    const end = start + state.pageSize;
    return { pageItems: items.slice(start, end), total, pages };
  }

  function renderPagination(pages) {
    const wrap = $("pagination");
    wrap.innerHTML = "";
    if (pages <= 1) return;

    const makeBtn = (label, page, active) => {
      const b = document.createElement("button");
      b.className = "pg-btn" + (active ? " pg-active" : "");
      b.textContent = label;
      b.addEventListener("click", () => { state.page = page; renderAll(); });
      return b;
    };

    const windowSize = 9;
    const half = Math.floor(windowSize / 2);
    let start = Math.max(1, state.page - half);
    let end = Math.min(pages, start + windowSize - 1);
    start = Math.max(1, end - windowSize + 1);

    wrap.appendChild(makeBtn("«", 1, false));
    wrap.appendChild(makeBtn("‹", Math.max(1, state.page - 1), false));

    for (let p = start; p <= end; p++) {
      wrap.appendChild(makeBtn(String(p), p, p === state.page));
    }

    wrap.appendChild(makeBtn("›", Math.min(pages, state.page + 1), false));
    wrap.appendChild(makeBtn("»", pages, false));
  }

  function renderTable(itemsPage) {
    const tbody = $("tbody");
    tbody.innerHTML = "";

    for (const it of itemsPage) {
      const tr = document.createElement("tr");

      const tdImg = document.createElement("td");
      const img = document.createElement("img");
      img.className = "cover";
      img.alt = it.title;
      const url = pickImageUrl(it.product);
      if (url) img.src = url;
      tdImg.appendChild(img);

      const tdName = document.createElement("td");
      tdName.textContent = it.title;

      const tdPub = document.createElement("td");
      tdPub.textContent = it.pub || "—";

      const tdDev = document.createElement("td");
      tdDev.textContent = it.dev || "—";

      const tdGenre = document.createElement("td");
      tdGenre.textContent = it.genre || "—";

      const tdYear = document.createElement("td");
      tdYear.textContent = it.year || "—";


      const tdAdded = document.createElement("td");
      tdAdded.textContent = it.added || "—";

      tr.appendChild(tdAdded);

      const tdAct = document.createElement("td");
      const btn = document.createElement("button");
      btn.className = "btn-read";
      btn.type = "button";
      btn.textContent = "Details";
      btn.addEventListener("click", (e) => { e.stopPropagation(); openModal(it.gameid); });
      tdAct.appendChild(btn);

      tr.appendChild(tdImg);
      tr.appendChild(tdName);
      tr.appendChild(tdPub);
      tr.appendChild(tdDev);
      tr.appendChild(tdGenre);
      tr.appendChild(tdYear);
      tr.appendChild(tdAct);

      tr.addEventListener("click", () => openModal(it.gameid));
      tbody.appendChild(tr);
    }
  }

  function renderTiles(itemsPage) {
    const tiles = $("tiles");
    tiles.innerHTML = "";

    for (const it of itemsPage) {
      const tile = document.createElement("div");
      tile.className = "tile";
      tile.tabIndex = 0;

      const img = document.createElement("img");
      const url = pickImageUrl(it.product);
      if (url) img.src = url;
      img.alt = it.title;

      const title = document.createElement("div");
      title.className = "tile-title";
      title.textContent = it.title;

      const sub = document.createElement("div");
      sub.className = "tile-sub";
      const genreShort = it.genre ? it.genre.split(",")[0].trim() : "";
      sub.textContent = [it.pub, it.dev, it.year, genreShort].filter(Boolean).join(" • ") || "—";

      tile.appendChild(img);
      tile.appendChild(title);
      tile.appendChild(sub);

      tile.addEventListener("click", () => openModal(it.gameid));
      tile.addEventListener("keypress", (e) => { if (e.key === "Enter" || e.key === " ") openModal(it.gameid); });

      tiles.appendChild(tile);
    }
    // Pad last row with invisible placeholders so the grid looks "filled".
    // We use 5 columns by design (see style.css), so keep page sizes multiple of 5.
    const cols = 5;
    const rem = itemsPage.length % cols;
    if (rem !== 0) {
      const pad = cols - rem;
      for (let i = 0; i < pad; i++) {
        const ph = document.createElement("div");
        ph.className = "tile placeholder";
        ph.setAttribute("aria-hidden", "true");
        tiles.appendChild(ph);
      }
    }
  }

  function openModal(gameid) {
    const prods = getProducts();
    const product = prods[gameid];
    if (!product) return;

    const title = getTitle(product, gameid);
    const pub = getPublisher(product);
    const rawDate = getReleaseDateRaw(product);
    const desc = getDescription(product);
    const imgUrl = pickImageUrl(product);

    $("modalTitle").textContent = title;

    const body = document.createElement("div");

    const hero = document.createElement("div");
    hero.className = "game-hero";

    const poster = document.createElement("img");
    poster.className = "game-poster";
    poster.alt = title;
    if (imgUrl) poster.src = imgUrl;

    const info = document.createElement("div");
    info.className = "game-info";

    const t = document.createElement("div");
    t.className = "game-title";
    t.textContent = title;

    const sub = document.createElement("div");
    sub.className = "game-sub";
    const dev = getDeveloper(product);
    sub.textContent = [pub, dev, rawDate].filter(Boolean).join(" • ");

    const kv = document.createElement("div");
    kv.className = "kv";
    const mkTag = (txt) => {
      const s = document.createElement("span");
      s.className = "tag";
      s.textContent = txt;
      return s;
    };
    kv.appendChild(mkTag("Lang: " + state.lang));
    kv.appendChild(mkTag("ID: " + gameid));
    const pub2 = getPublisher(product);
    if (pub2) kv.appendChild(mkTag("Publisher: " + pub2));
    const dev2 = getDeveloper(product);
    if (dev2) kv.appendChild(mkTag("Developer: " + dev2));
    const gn2 = getGenresText(product);
    if (gn2) kv.appendChild(mkTag("Genre: " + gn2));
    const yr = getReleaseYear(product);
    if (yr) kv.appendChild(mkTag("Year: " + yr));
    
    const ad = getAddedDateDisplay(product);
    if (ad) kv.appendChild(mkTag("Added: " + ad));
kv.appendChild(mkTag("List: " + state.listKey));

    const descEl = document.createElement("div");
    descEl.className = "desc-text";
    descEl.textContent = desc || "(No description in this locale)";

    info.appendChild(t);
    info.appendChild(sub);
    info.appendChild(kv);

    hero.appendChild(poster);
    hero.appendChild(info);

    body.appendChild(hero);
    body.appendChild(descEl);

    const modalContent = $("modalContent");
    modalContent.innerHTML = "";
    modalContent.appendChild(body);

    const overlay = $("modalOverlay");
    overlay.classList.add("open");
    overlay.setAttribute("aria-hidden", "false");
    $("modalClose").focus();
  }

  function closeModal() {
    const overlay = $("modalOverlay");
    overlay.classList.remove("open");
    overlay.setAttribute("aria-hidden", "true");
  }

  function populateLists() {
    const lists = getLists();
    const sel = $("listSel");
    if (!sel) return;

    const entries = Object.entries(lists).map(([key, obj]) => ({
      key,
      title: (obj && obj.title) ? obj.title : key,
      group: (obj && obj.group) ? obj.group : "Lists",
      count: (obj && Array.isArray(obj.items)) ? obj.items.length : 0,
    }));

    entries.sort((a, b) => (a.group.localeCompare(b.group) || a.title.localeCompare(b.title)));

    sel.innerHTML = "";
    const groups = new Map();
    for (const it of entries) {
      if (!groups.has(it.group)) groups.set(it.group, []);
      groups.get(it.group).push(it);
    }

    for (const [gname, arr] of groups.entries()) {
      const og = document.createElement("optgroup");
      og.label = gname;
      for (const it of arr) {
        const opt = document.createElement("option");
        opt.value = it.key;
        opt.textContent = `${it.title} (${it.count})`;
        og.appendChild(opt);
      }
      sel.appendChild(og);
    }

    if (!lists[state.listKey]) {
      state.listKey = entries.length ? entries[0].key : "pcgaVTaz";
    }
    sel.value = state.listKey;
  }

  function renderAll() {
    const all = getEntriesFilteredSorted();
    const { pageItems, total, pages } = paginate(all);

    $("countTxt").value = `${state.lang}: ${total} games`;

    if (state.view === "table") renderTable(pageItems);
    else renderTiles(pageItems);

    renderPagination(pages);
  }

  function initSortHandlers() {
    document.querySelectorAll("th.sortable").forEach((th) => {
      th.addEventListener("click", () => {
        const key = th.getAttribute("data-key");
        if (key) setSort(key);
      });
    });
  }

  function initFab() {
    const fs = document.querySelector(".float-settings");
    $("fabMain").addEventListener("click", () => {
      fs.classList.toggle("open");
    });
    document.addEventListener("click", (e) => {
      if (!fs.contains(e.target)) fs.classList.remove("open");
    });
  }

  function initModalHandlers() {
    $("modalClose").addEventListener("click", closeModal);
    $("modalOverlay").addEventListener("click", (e) => {
      if (e.target === $("modalOverlay")) closeModal();
    });
    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape") closeModal();
    });
  }

  function init() {
    try {
      const th = localStorage.getItem("gp_theme");
      if (th === "dark" || th === "light") state.theme = th;
      const lg = localStorage.getItem("gp_lang");
      if (lg === "EN" || lg === "UA") state.lang = lg;
      const lk = localStorage.getItem("gp_list");
      if (lk) state.listKey = lk;
    } catch (_) {}

    setTheme(state.theme);
    $("btnLang").textContent = state.lang;

    $("btnTable").addEventListener("click", () => setView("table"));
    $("btnTiles").addEventListener("click", () => setView("tiles"));

    $("searchTxt").addEventListener("input", (e) => {
      state.q = e.target.value || "";
      state.page = 1;
      renderAll();
    });

    $("listSel").addEventListener("change", (e) => {
      state.listKey = e.target.value;
      state.page = 1;
      try { localStorage.setItem("gp_list", state.listKey); } catch (_) {}
      renderAll();
    });

    $("btnReset").addEventListener("click", () => {
      state.q = "";
      $("searchTxt").value = "";
      state.sortKey = "name";
      state.sortDir = "asc";
      state.page = 1;
      state.listKey = "pcgaVTaz";
      try { localStorage.setItem("gp_list", state.listKey); } catch (_) {}
      $("listSel").value = state.listKey;
      renderAll();
    });

    $("btnTheme").addEventListener("click", () => {
      toggleTheme();
      renderAll();
    });

    $("btnLang").addEventListener("click", toggleLang);

    initSortHandlers();
    initFab();
    initModalHandlers();

    populateLists();
    renderAll();
  }

  init();
})();