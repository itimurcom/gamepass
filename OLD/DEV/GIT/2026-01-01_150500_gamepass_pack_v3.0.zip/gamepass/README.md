# Game Pass (v3.0)

## Головні правила (зафіксовано)
1. Інтерфейс скрипта — українською.
2. Дані про ігри — українською, якщо є офіційно (Store/Wikidata), інакше fallback на англійську.
   - Назви ігор залишаються оригінальні.
3. Кеш завжди в: `~/.gamepass`

## Запуск
```bash
chmod +x gamepass.py
./gamepass.py
```

## Параметри
- `--reset-cache` — очистити кеш і почати спочатку
- `--no-wikidata` — не тягнути дані з Wikidata
- `--hltb` — години (HowLongToBeat) (потрібен howlongtobeatpy)
- `--market US|UA|...` — ринок
- `--data-lang uk-ua` — основна мова даних (за замовчуванням uk-ua)
- `--fallback-lang en-us` — fallback мова (за замовчуванням en-us)
- `--pass-size 100` — крок завантаження зі Store

## Залежності (опційно, рекомендовано)
На Ubuntu/Debian (PEP 668) став через venv:
```bash
sudo apt install -y python3-venv python3-full
python3 -m venv .venv
source .venv/bin/activate
pip install tqdm howlongtobeatpy
./gamepass.py --hltb
```

## Вихідні файли
- `gamepass_catalog.html`
- `gamepass_catalog.csv`

Згенеровано: 2026-01-01_150500 (Europe/Kyiv)
