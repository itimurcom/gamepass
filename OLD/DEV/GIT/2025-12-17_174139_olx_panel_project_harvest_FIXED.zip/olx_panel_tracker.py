#!/usr/bin/env python3
"""
OLX panel tracker (single-file) to build panel data for listings.

What it does:
- Harvest listing URLs from multiple OLX search-result pages (harvest)
- Seed a SQLite DB with listing URLs and take the first snapshot (seed)
- Update snapshots for all URLs already in the DB (update)
- Export current listings table to CSV (export)

Notes:
- Be polite: low request rate, random sleeps, respect OLX Terms/robots.
- This script does NOT bypass anti-bot protections.
"""

from __future__ import annotations

import argparse
import dataclasses
import datetime as dt
import json
import random
import re
import sqlite3
import sys
import time
import urllib.parse
from typing import Optional, Tuple, List

import requests

DB_SCHEMA = """
PRAGMA journal_mode=WAL;

CREATE TABLE IF NOT EXISTS listings (
  listing_id TEXT PRIMARY KEY,
  url TEXT NOT NULL,
  first_seen_utc TEXT NOT NULL,
  last_seen_utc TEXT NOT NULL,
  first_price_uah REAL,
  last_price_uah REAL,
  currency TEXT,
  is_active INTEGER NOT NULL DEFAULT 1,
  title TEXT,
  posted_date TEXT,
  location TEXT
);

CREATE TABLE IF NOT EXISTS snapshots (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  listing_id TEXT NOT NULL,
  seen_utc TEXT NOT NULL,
  is_active INTEGER NOT NULL,
  price_uah REAL,
  currency TEXT,
  title TEXT,
  posted_date TEXT,
  location TEXT,
  raw_price_text TEXT,
  FOREIGN KEY(listing_id) REFERENCES listings(listing_id)
);

CREATE INDEX IF NOT EXISTS idx_snapshots_listing_time ON snapshots(listing_id, seen_utc);
"""

UAH_RE = re.compile(r"([0-9][0-9\s\u00A0]*)\s*грн", re.IGNORECASE)
# Full listing URL with IDxxxxxx.html
LINK_RE = re.compile(r"https?://www\.olx\.ua/[^\s\"']+ID[0-9A-Za-z]+\.html", re.IGNORECASE)


def utc_now_iso() -> str:
    return dt.datetime.utcnow().replace(microsecond=0).isoformat() + "Z"


def sleep_polite(min_s: float, max_s: float) -> None:
    time.sleep(random.uniform(min_s, max_s))


def normalize_spaces(s: str) -> str:
    return re.sub(r"[\s\u00A0]+", " ", s).strip()


def extract_listing_id(url: str) -> str:
    m = re.search(r"(ID[0-9A-Za-z]+)\.html", url)
    if not m:
        raise ValueError(f"Cannot extract listing ID from URL: {url}")
    return m.group(1)


def http_get(session: requests.Session, url: str, timeout_s: int = 25) -> requests.Response:
    headers = {
        "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
                      "(KHTML, like Gecko) Chrome/120 Safari/537.36",
        "Accept-Language": "uk-UA,uk;q=0.9,en-US;q=0.8,en;q=0.7",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Connection": "keep-alive",
    }
    return session.get(url, headers=headers, timeout=timeout_s)


@dataclasses.dataclass
class ListingSnapshot:
    listing_id: str
    url: str
    seen_utc: str
    is_active: bool
    price_uah: Optional[float] = None
    currency: Optional[str] = None
    title: Optional[str] = None
    posted_date: Optional[str] = None
    location: Optional[str] = None
    raw_price_text: Optional[str] = None


def parse_price_uah(html: str) -> Tuple[Optional[float], Optional[str], Optional[str]]:
    """
    Best-effort parsing:
    1) JSON-LD (Product/Offer) if present
    2) Text match "... грн"
    Returns: (price_uah, currency, raw_price_text)
    """
    # JSON-LD first
    for m in re.finditer(r'<script[^>]+type="application/ld\+json"[^>]*>(.*?)</script>', html, re.DOTALL | re.IGNORECASE):
        blob = m.group(1).strip()
        if not blob:
            continue
        try:
            data = json.loads(blob)
        except Exception:
            continue

        objs = data if isinstance(data, list) else [data]
        for obj in objs:
            if not isinstance(obj, dict):
                continue
            offers = obj.get("offers")
            if isinstance(offers, dict):
                price = offers.get("price")
                currency = offers.get("priceCurrency")
                if price is not None:
                    try:
                        return float(str(price).replace(",", ".")), currency or "UAH", None
                    except Exception:
                        pass

    # Text fallback
    m = UAH_RE.search(html)
    if not m:
        return None, None, None
    raw = m.group(0)
    digits = normalize_spaces(m.group(1)).replace(" ", "")
    try:
        return float(digits), "UAH", raw
    except Exception:
        return None, "UAH", raw


def parse_title(html: str) -> Optional[str]:
    m = re.search(r"<title>(.*?)</title>", html, re.IGNORECASE | re.DOTALL)
    if not m:
        return None
    t = normalize_spaces(re.sub(r"</?[^>]+>", "", m.group(1)))
    t = t.replace(" - OLX.ua", "").strip()
    return t or None


def parse_posted_date(html: str) -> Optional[str]:
    # Very best-effort. Markup changes often.
    m = re.search(r"(\d{4}-\d{2}-\d{2})", html)
    return m.group(1) if m else None


def parse_location(html: str) -> Optional[str]:
    m = re.search(r'data-testid="location-date"[^>]*>(.*?)</', html, re.IGNORECASE | re.DOTALL)
    if not m:
        return None
    txt = normalize_spaces(re.sub(r"</?[^>]+>", "", m.group(1)))
    return txt or None


def is_page_active(html: str) -> bool:
    bad_phrases = [
        "Оголошення не знайдено",
        "Объявление не найдено",
        "Вибачте, це оголошення більше не доступне",
        "Sorry, this ad is no longer available",
        "404",
    ]
    h = html.lower()
    return not any(p.lower() in h for p in bad_phrases)


def fetch_snapshot(session: requests.Session, url: str) -> ListingSnapshot:
    listing_id = extract_listing_id(url)
    seen = utc_now_iso()

    resp = http_get(session, url)
    html = resp.text if resp is not None else ""

    active = is_page_active(html)
    price_uah, currency, raw_price = parse_price_uah(html) if active else (None, None, None)
    title = parse_title(html) if active else None
    posted = parse_posted_date(html) if active else None
    location = parse_location(html) if active else None

    return ListingSnapshot(
        listing_id=listing_id,
        url=url,
        seen_utc=seen,
        is_active=active,
        price_uah=price_uah,
        currency=currency,
        title=title,
        posted_date=posted,
        location=location,
        raw_price_text=raw_price,
    )


def connect_db(db_path: str) -> sqlite3.Connection:
    con = sqlite3.connect(db_path)
    con.execute("PRAGMA foreign_keys=ON;")
    con.executescript(DB_SCHEMA)
    return con


def upsert_listing(con: sqlite3.Connection, snap: ListingSnapshot) -> None:
    cur = con.cursor()
    cur.execute("SELECT listing_id FROM listings WHERE listing_id=?", (snap.listing_id,))
    row = cur.fetchone()

    if row is None:
        cur.execute(
            """INSERT INTO listings(listing_id, url, first_seen_utc, last_seen_utc, first_price_uah, last_price_uah,
                                    currency, is_active, title, posted_date, location)
               VALUES(?,?,?,?,?,?,?,?,?,?,?)""",
            (
                snap.listing_id, snap.url, snap.seen_utc, snap.seen_utc,
                snap.price_uah, snap.price_uah, snap.currency,
                1 if snap.is_active else 0,
                snap.title, snap.posted_date, snap.location,
            ),
        )
    else:
        cur.execute(
            """UPDATE listings
               SET url=?,
                   last_seen_utc=?,
                   last_price_uah=?,
                   currency=?,
                   is_active=?,
                   title=COALESCE(?, title),
                   posted_date=COALESCE(?, posted_date),
                   location=COALESCE(?, location)
               WHERE listing_id=?""",
            (
                snap.url, snap.seen_utc,
                snap.price_uah if snap.price_uah is not None else None,
                snap.currency,
                1 if snap.is_active else 0,
                snap.title, snap.posted_date, snap.location,
                snap.listing_id,
            ),
        )

    cur.execute(
        """INSERT INTO snapshots(listing_id, seen_utc, is_active, price_uah, currency, title, posted_date, location, raw_price_text)
           VALUES(?,?,?,?,?,?,?,?,?)""",
        (
            snap.listing_id, snap.seen_utc, 1 if snap.is_active else 0,
            snap.price_uah, snap.currency, snap.title, snap.posted_date, snap.location, snap.raw_price_text,
        ),
    )
    con.commit()


def seed_from_file(path: str) -> List[str]:
    urls: List[str] = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            urls.append(line)
    return urls


def extract_listing_urls_from_html(html: str) -> List[str]:
    links = []
    links.extend(LINK_RE.findall(html))

    rel = re.findall(r'href="([^"]+ID[0-9A-Za-z]+\.html)"', html, re.IGNORECASE)
    for r in rel:
        if r.startswith("http"):
            links.append(r)
        else:
            links.append(urllib.parse.urljoin("https://www.olx.ua/", r.lstrip("/")))

    # Dedupe preserve order
    out: List[str] = []
    seen = set()
    for u in links:
        u = u.strip()
        if not u or u in seen:
            continue
        seen.add(u)
        out.append(u)
    return out


def build_paged_url(search_url: str, page: int) -> str:
    """
    Return a URL for a given search page number.
    OLX commonly uses ?page=N on search results.
    """
    parsed = urllib.parse.urlsplit(search_url)
    qs = urllib.parse.parse_qs(parsed.query, keep_blank_values=True)
    qs["page"] = [str(page)]
    new_query = urllib.parse.urlencode(qs, doseq=True)
    return urllib.parse.urlunsplit((parsed.scheme, parsed.netloc, parsed.path, new_query, parsed.fragment))


def harvest_urls_from_search(session: requests.Session, search_url: str, max_pages: int, max_urls: int, sleep_min: float, sleep_max: float) -> List[str]:
    """
    Crawl multiple search result pages and extract listing URLs.
    Returns unique URLs (preserve order).
    """
    out: List[str] = []
    seen = set()

    for page in range(1, max_pages + 1):
        page_url = build_paged_url(search_url, page)
        try:
            resp = http_get(session, page_url)
            html = resp.text
        except Exception:
            html = ""

        links = extract_listing_urls_from_html(html)
        added = 0
        for u in links:
            if u in seen:
                continue
            seen.add(u)
            out.append(u)
            added += 1
            if len(out) >= max_urls:
                return out

        print(f"[harvest] page={page} added={added} total={len(out)} url={page_url}")

        # Stop early if no new URLs
        if added == 0:
            break

        sleep_polite(sleep_min, sleep_max)

    return out


def seed_from_search_url(session: requests.Session, search_url: str, max_urls: int) -> List[str]:
    resp = http_get(session, search_url)
    return extract_listing_urls_from_html(resp.text)[:max_urls]


def cmd_harvest(args: argparse.Namespace) -> int:
    session = requests.Session()
    urls = harvest_urls_from_search(session, args.search_url, args.pages, args.max_urls, args.sleep_min, args.sleep_max)
    if not urls:
        print("No URLs harvested. Try another search URL, or reduce filters.")
        return 2
    with open(args.out_urls, "w", encoding="utf-8") as f:
        f.write("\n".join(urls) + "\n")
    print(f"Harvested: {len(urls)} URLs -> {args.out_urls}")
    return 0


def cmd_seed(args: argparse.Namespace) -> int:
    con = connect_db(args.db)
    session = requests.Session()

    urls: List[str] = []
    if args.urls_file:
        urls.extend(seed_from_file(args.urls_file))
    if args.search_url:
        urls.extend(seed_from_search_url(session, args.search_url, args.max_urls))

    # Dedupe preserve order
    dedup: List[str] = []
    seen = set()
    for u in urls:
        u = u.strip()
        if not u or u in seen:
            continue
        seen.add(u)
        dedup.append(u)
    urls = dedup

    if not urls:
        print("No URLs to seed. Use --urls-file or --search-url.")
        return 2

    print(f"Seeding {len(urls)} URLs...")
    for i, url in enumerate(urls, 1):
        try:
            snap = fetch_snapshot(session, url)
            upsert_listing(con, snap)
            print(f"[{i}/{len(urls)}] {snap.listing_id} active={snap.is_active} price={snap.price_uah} url={url}")
        except Exception as e:
            print(f"[{i}/{len(urls)}] ERROR {url}: {e}", file=sys.stderr)
        sleep_polite(args.sleep_min, args.sleep_max)

    print("Done.")
    return 0


def cmd_update(args: argparse.Namespace) -> int:
    con = connect_db(args.db)
    session = requests.Session()
    cur = con.cursor()

    cur.execute("SELECT url FROM listings")
    urls = [r[0] for r in cur.fetchall()]
    if not urls:
        print("No listings in DB. Run seed first.")
        return 2

    print(f"Updating {len(urls)} listings...")
    for i, url in enumerate(urls, 1):
        try:
            snap = fetch_snapshot(session, url)
            upsert_listing(con, snap)
            print(f"[{i}/{len(urls)}] {snap.listing_id} active={snap.is_active} price={snap.price_uah}")
        except Exception as e:
            print(f"[{i}/{len(urls)}] ERROR {url}: {e}", file=sys.stderr)
        sleep_polite(args.sleep_min, args.sleep_max)

    print("Done.")
    return 0


def cmd_export(args: argparse.Namespace) -> int:
    con = connect_db(args.db)
    out = args.out_csv

    q = """
    SELECT
      l.listing_id,
      l.url,
      l.first_seen_utc,
      l.last_seen_utc,
      l.is_active,
      l.first_price_uah,
      l.last_price_uah,
      l.title,
      l.posted_date,
      l.location
    FROM listings l
    """
    try:
        import pandas as pd
        df = pd.read_sql_query(q, con)
        df.to_csv(out, index=False, encoding="utf-8")
        print(f"Exported: {out} ({len(df)} rows)")
    except ImportError:
        cur = con.cursor()
        cur.execute(q)
        cols = [d[0] for d in cur.description]
        rows = cur.fetchall()
        with open(out, "w", encoding="utf-8") as f:
            f.write(",".join(cols) + "\n")
            for r in rows:
                f.write(",".join("" if v is None else str(v).replace(",", " ") for v in r) + "\n")
        print(f"Exported: {out} ({len(rows)} rows) [no pandas]")
    return 0


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="OLX panel tracker (SQLite)")
    p.add_argument("--db", default="olx_panel.sqlite3", help="SQLite DB path")

    sub = p.add_subparsers(dest="cmd", required=True)

    ph = sub.add_parser("harvest", help="Harvest listing URLs from multiple OLX search result pages to a text file")
    ph.add_argument("--search-url", required=True, help="OLX search URL (result list)")
    ph.add_argument("--pages", type=int, default=30, help="Max pages to scan (default 30)")
    ph.add_argument("--max-urls", type=int, default=1500, help="Stop after this many URLs (default 1500)")
    ph.add_argument("--out-urls", default="seed_urls.txt", help="Output text file with URLs")
    ph.add_argument("--sleep-min", type=float, default=1.0, help="Polite sleep min seconds between pages")
    ph.add_argument("--sleep-max", type=float, default=2.2, help="Polite sleep max seconds between pages")
    ph.set_defaults(func=cmd_harvest)

    ps = sub.add_parser("seed", help="Seed URLs into DB and take first snapshot")
    ps.add_argument("--urls-file", help="Text file with listing URLs (one per line)")
    ps.add_argument("--search-url", help="OLX search URL to extract listing URLs from (single page only)")
    ps.add_argument("--max-urls", type=int, default=200, help="Max URLs to take from search page")
    ps.add_argument("--sleep-min", type=float, default=1.2, help="Polite sleep min seconds")
    ps.add_argument("--sleep-max", type=float, default=2.8, help="Polite sleep max seconds")
    ps.set_defaults(func=cmd_seed)

    pu = sub.add_parser("update", help="Refresh snapshots for all URLs in DB")
    pu.add_argument("--sleep-min", type=float, default=1.2)
    pu.add_argument("--sleep-max", type=float, default=2.8)
    pu.set_defaults(func=cmd_update)

    pe = sub.add_parser("export", help="Export listings table to CSV")
    pe.add_argument("--out-csv", default="listings_export.csv")
    pe.set_defaults(func=cmd_export)

    return p


def main() -> int:
    args = build_parser().parse_args()
    return int(args.func(args))


if __name__ == "__main__":
    raise SystemExit(main())
