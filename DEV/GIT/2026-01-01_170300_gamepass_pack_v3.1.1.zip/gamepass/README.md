# Game Pass v3.1.1

## КРИТИЧНИЙ ФІКС
- Виправлено помилку `SyntaxError: unterminated string literal` у прогрес-індикаторі.
- Було: рядок розривався на 2 лінії:
  - `out = "`
  - `" + line`
- Стало: один рядок:
  - `out = "\r" + line`

## Перевірка
```bash
python3 -m py_compile ./gamepass.py
```

Згенеровано: 2026-01-01_170300 (Europe/Kyiv)
