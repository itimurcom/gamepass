from __future__ import annotations

import os
import sys
import time
from typing import Final


# ANSI colors (works in most terminals). Can be disabled with NO_COLOR=1
ANSI_RESET: Final[str] = "\x1b[0m"
ANSI_GREEN_LIGHT: Final[str] = "\x1b[92m"
ANSI_BLUE: Final[str] = "\x1b[94m"
ANSI_YELLOW: Final[str] = "\x1b[93m"
ANSI_RED: Final[str] = "\x1b[91m"


def _use_color() -> bool:
    if os.environ.get("NO_COLOR"):
        return False
    # If not a TTY, colors might be noisy in logs; keep off by default then.
    try:
        return sys.stderr.isatty()
    except Exception:
        return False


def _ts() -> str:
    return time.strftime("%H:%M:%S")


def _emit(tag: str, color: str, msg: str) -> None:
    if _use_color():
        print(f"{color}{tag}{ANSI_RESET} {msg}", file=sys.stderr)
    else:
        print(f"{tag} {msg}", file=sys.stderr)


def log_process(msg: str) -> None:
    _emit("[PROCESS]", ANSI_GREEN_LIGHT, f"{_ts()} {msg}")


def log_info(msg: str) -> None:
    _emit("[INFO]", ANSI_BLUE, f"{_ts()} {msg}")


def log_warn(msg: str) -> None:
    _emit("[WARN]", ANSI_YELLOW, f"{_ts()} {msg}")


def log_error(msg: str) -> None:
    _emit("[ERROR]", ANSI_RED, f"{_ts()} {msg}")
