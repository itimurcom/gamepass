# PATCH NOTE:
# Adds detailed progress stages during parsing without changing logic.
# One goal: visibility only.

import sys, os, json, time

def progress(line):
    sys.stdout.write("\r" + line)
    sys.stdout.flush()

# --- existing code assumed above ---

def parse_product_local(bid, DIRS, _orig_parse=None):
    # Wrapper to add stage visibility; calls original logic sections.
    # This function assumes the original parse_product_local is available as _orig_parse
    progress(f"Аналіз | {bid} | load product json")
    row = _orig_parse(bid, DIRS, stage_cb=lambda s: progress(f"Аналіз | {bid} | {s}"))
    progress(f"Аналіз | {bid} | done")
    return row

# --- existing code continues ---