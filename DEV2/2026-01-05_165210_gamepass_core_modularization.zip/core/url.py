from __future__ import annotations

import urllib.parse
from typing import Dict


def build_url(base: str, params: Dict[str, str]) -> str:
    return base + "?" + urllib.parse.urlencode(params)
