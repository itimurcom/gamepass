#!/usr/bin/env python3
"""
PC Game Pass catalog dumper (EN/US only) - stdlib only

Output:
  .cache/            one raw Microsoft Store product JSON per game (ProductId.json)
  .cache/_meta/      meta files (SIGL dump etc.)
"""

from __future__ import annotations

import time
from pathlib import Path

from core.gp_config import Config, PC_GAMEPASS_SIGL
from core.gp_sigl import fetch_sigl_big_ids
from core.gp_terminal import (
    log_error,
    log_warn,
    print_overall_result,
    print_project,
    print_stage,
    print_stage_result,
    progress_done,
    progress_update,
)
from core.core import chunked, ensure_dirs, fetch_products, write_json, write_product

PROJECT_TITLE_WITH_VERSION = "Gamepass Parser v15.3"


def run(cfg: Config) -> None:
    print_project(PROJECT_TITLE_WITH_VERSION)

    meta_dir = ensure_dirs(cfg.out_dir)

    # ----------------
    # Stage 1: SIGL
    # ----------------
    stage_no = 1
    print_stage(stage_no, "Fetch PC Game Pass catalog ids (SIGL)")

    progress_update(0, 1, text="Requesting SIGL list...")
    try:
        ids, sigl_meta = fetch_sigl_big_ids(cfg)
    except Exception as e:
        progress_done(final_text="SIGL request failed")
        log_error(f"SIGL fetch failed: {e}")
        raise
    progress_update(1, 1, text="SIGL list received")
    progress_done()

    write_json(meta_dir / "sigl_US_en-us.json", sigl_meta)

    if not ids:
        print_stage_result(stage_no, "0 ids received (nothing to do)")
        log_warn("No bigIds received. Nothing to do.")
        print_overall_result("No data dumped.")
        return

    print_stage_result(stage_no, f"{len(ids)} ids saved to {meta_dir / 'sigl_US_en-us.json'}")

    # ----------------
    # Stage 2: Fetch+Write products (batched)
    # ----------------
    stage_no = 2
    print_stage(stage_no, "Fetch product details (DisplayCatalog) and write JSON files")

    ids_sorted = sorted(ids)
    batches = list(chunked(ids_sorted, cfg.batch_size))
    total_steps = len(batches) * 2  # fetch + write per batch
    step = 0

    products_fetched = 0
    files_written = 0

    for idx, batch in enumerate(batches, start=1):
        # Step: fetch
        step += 1
        progress_update(step, total_steps, text=f"Fetching batch {idx}/{len(batches)} ({len(batch)} ids)")
        try:
            products = fetch_products(cfg, batch)
        except Exception as e:
            progress_done(final_text=f"Batch {idx} fetch failed")
            log_error(f"DisplayCatalog fetch failed on batch {idx}/{len(batches)}: {e}")
            raise

        products_fetched += len(products)

        # Step: write
        step += 1
        progress_update(step, total_steps, text=f"Writing batch {idx}/{len(batches)} ({len(products)} products)")
        for p in products:
            if isinstance(p, dict):
                ok = write_product(cfg.out_dir, p)
                if ok:
                    files_written += 1

        time.sleep(cfg.sleep_s)

    progress_done(final_text="Batches processed")

    print_stage_result(stage_no, f"products_fetched={products_fetched}, files_written={files_written}")

    # ----------------
    # Stage 3: Summary
    # ----------------
    stage_no = 3
    print_stage(stage_no, "Summary")
    progress_update(1, 1, text="Preparing final summary...")
    progress_done()

    print_stage_result(stage_no, f"out_dir={cfg.out_dir}, meta_dir={meta_dir}")

    # Overall
    print_overall_result(
        f"ids={len(ids_sorted)}, products_fetched={products_fetched}, files_written={files_written}, out_dir={cfg.out_dir}"
    )


def main() -> None:
    cfg = Config(
        market="US",
        language="en-us",
        out_dir=Path(".cache"),
        sigl_id=PC_GAMEPASS_SIGL,
        batch_size=100,
        sleep_s=0.2,
        timeout_s=30.0,
        retries=3,
    )
    run(cfg)


if __name__ == "__main__":
    main()
