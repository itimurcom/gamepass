# OLX panel (“майже науково”)

Ціль: зібрати **панельні дані** по оголошеннях OLX (одні й ті самі URL у часі), щоб оцінювати:
- як **відносна ціна** впливає на **швидкість зникнення лота** (проксі продажу/видалення)
- і на цій базі підбирати кращі кроки markdown

> Важливо: скрипти не обходять антибот. Працюємо “ввічливо”: низький rate, паузи, без агресивного парсингу.

## Встановити залежності

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -U pip requests pandas
```

`pandas` необов’язковий, але зручний для export.

## 1) Harvest (зібрати багато URL автоматично)

Скрипт проходиться по сторінках видачі OLX і збирає URL в текстовий файл.

```bash
python olx_panel_tracker.py harvest \
  --search-url "https://www.olx.ua/d/uk/list/q-rtx-4070-%D0%BD%D0%BE%D1%83%D1%82%D0%B1%D1%83%D0%BA/" \
  --pages 30 --max-urls 1500 --out-urls seed_urls.txt
```

## 2) Seed (перший знімок)

```bash
python olx_panel_tracker.py seed --db olx_panel.sqlite3 --urls-file seed_urls.txt
```

## 3) Update (щоденний/двічі на день)

```bash
python olx_panel_tracker.py update --db olx_panel.sqlite3
```

## 4) Аналіз + HTML dashboard

```bash
python olx_panel_analyze.py --db olx_panel.sqlite3 --out olx_panel_dashboard.html
```

Відкрий `olx_panel_dashboard.html` у браузері.

## Поради по якості даних
- Краще 500–1500 лотів і update 1–2 рази/день, ніж “дуже багато за раз”.
- Для “правильнішої” оцінки додамо пізніше: price changes (time‑varying), фільтри по конфігу (RAM/SSD), регіон.
