# gp_logic.py
# Логіка: Dual-Language Extraction + Smart Metrics

import os
import json
import re

import html
# --- КОНСТАНТИ ---
AAA_PUBLISHERS = [
    "xbox game studios", "bethesda", "electronic arts", "ea", "ubisoft", 
    "activision", "blizzard", "rockstar", "2k", "capcom", "square enix", 
    "bandai namco", "sega", "wb games", "sony", "cd projekt", "take-two",
    "konami", "riot games", "bungie", "epic games"
]

INDIE_MARKERS = ["indie", "independent", "аркади", "arcade", "platformer", "puzzle"]

# --- УТИЛІТИ ---
def safe_name(s):
    return "".join(c for c in (s or "").lower() if c.isalnum() or c in "-_")[:180] or "x"

def rw_json(path, data=None):
    if data is None: # Read
        if os.path.exists(path):
            try:
                with open(path, "r", encoding="utf-8") as f:
                    content = json.load(f)
                    if not content: return None 
                    return content
            except (json.JSONDecodeError, OSError):
                return None
        return None
    else: # Write
        tmp = path + ".tmp"
        try:
            with open(tmp, "w", encoding="utf-8") as f: 
                json.dump(data, f, ensure_ascii=False, indent=2)
            os.replace(tmp, path)
        except Exception as e:
            print(f"[ERROR] Не вдалося записати {path}: {e}")

def clean_html(txt):
    if not txt: return ""
    return re.sub(r'<[^>]+>', '', txt).strip()

# --- БІЗНЕС-ЛОГІКА ---

def analyze_metrics(product_raw, wikidata_data, genres_str):
    """Визначає Tier та Рейтинг."""
    props = product_raw.get("Properties", {})
    market_props = product_raw.get("MarketProperties", [])
    
    # Видавець (беремо англійську назву як універсальну)
    lps = product_raw.get("LocalizedProperties", [])
    lp_en = next((x for x in lps if x.get("Language","").lower() == "en-us"), lps[0] if lps else {})
    publisher = (lp_en.get("PublisherName") or props.get("PublisherName") or "").lower()
    
    # Розмір
    max_size_gb = 0
    if product_raw.get("DisplaySkuAvailabilities"):
        for sku_avail in product_raw["DisplaySkuAvailabilities"]:
            pkg = sku_avail.get("Sku", {}).get("Properties", {}).get("Packages", [])
            if pkg:
                size_bytes = pkg[0].get("MaxDownloadFileSizeInBytes", 0)
                max_size_gb = max(max_size_gb, size_bytes / (1024**3))

    # Tier Logic
    is_aaa_publisher = any(p in publisher for p in AAA_PUBLISHERS)
    is_huge_game = max_size_gb > 45
    is_indie_genre = any(m in genres_str.lower() for m in INDIE_MARKERS)
    
    tier = "Indie/AA"
    if (is_aaa_publisher or is_huge_game) and not is_indie_genre:
        tier = "AAA"
    
    # Rating Logic
    ms_score = 0
    ms_count = 0
    for mp in market_props:
        usage = mp.get("UsageData", [])
        for u in usage:
            if u.get("AggregateTimeSpan") == "AllTime":
                ms_score = u.get("AverageRating", 0)
                ms_count = u.get("RatingCount", 0)
                break
        if ms_count > 0: break
    
    wd_score_raw = wikidata_data.get("Rating", 0)
    wd_score = 0
    try:
        wd_val = float(str(wd_score_raw).split("/")[0])
        if wd_val <= 5: wd_score = wd_val * 20
        elif wd_val <= 10: wd_score = wd_val * 10
        else: wd_score = wd_val
    except: pass

    final_score = 0
    if ms_count > 0:
        R = ms_score * 20
        v = ms_count
        m = 50 
        C = 75 
        final_score = (v / (v + m)) * R + (m / (v + m)) * C
    elif wd_score > 0:
        final_score = wd_score
    
    score_src = f"{ms_count} (Xbox)" if ms_count else ("Wiki" if wd_score > 0 else "")
    
    return tier, round(final_score, 1), score_src

def get_product_data(bid, dirs, lang_pref="uk-ua"):
    path = os.path.join(dirs["products"], f"{safe_name(bid)}.json")
    cache = rw_json(path)
    if not cache or "product" not in cache: return None 
        
    p = cache["product"]
    props = p.get("Properties", {})
    lps = p.get("LocalizedProperties", [])
    
    # --- DUAL LANGUAGE EXTRACTION ---
    # Шукаємо дані для UA та EN
    lp_uk = next((x for x in lps if x.get("Language","").lower() == "uk-ua"), {})
    lp_en = next((x for x in lps if x.get("Language","").lower() == "en-us"), {})
    
    # Fallback: якщо немає UA, беремо EN. Якщо немає EN, беремо перший ліпший.
    lp_main = lp_uk if lp_uk else (lp_en if lp_en else (lps[0] if lps else {}))
    
    # Назви
    name_uk = lp_uk.get("ProductTitle") or lp_en.get("ProductTitle") or p.get("ProductTitle") or ""
    name_en = lp_en.get("ProductTitle") or name_uk
    
    # Описи (Store)
    desc_uk = clean_html(lp_uk.get("ShortDescription") or lp_uk.get("ProductDescription") or "")
    desc_en = clean_html(lp_en.get("ShortDescription") or lp_en.get("ProductDescription") or "")
    
    if not name_uk: return None

    # Картинка (беремо з будь-якого доступного джерела, картинки не залежать від мови)
    imgs = lp_main.get("Images", [])
    if not imgs and p.get("DisplaySkuAvailabilities"):
        skus = p.get("DisplaySkuAvailabilities")[0].get("Sku", {}).get("LocalizedProperties", [])
        if skus: imgs = skus[0].get("Images", [])
    img_url = next((i.get("Uri") for i in imgs if i.get("ImagePurpose") in ["Poster", "BoxArt"]), imgs[0].get("Uri") if imgs else "")
    if img_url and img_url.startswith("//"): img_url = "https:" + img_url

    # Пошук в кешах (Wiki/HLTB) робимо за очищеною назвою
    search_name = name_en.replace("(Game Preview)", "").replace("(PC)", "").strip()

    # Wikidata
    wd_cache_name = rw_json(os.path.join(dirs["wikidata"], f"{safe_name(search_name)}.json"))
    qid = wd_cache_name.get("qid") if wd_cache_name else None
    wd_data = {}
    if qid:
        wd_raw = rw_json(os.path.join(dirs["wd_sparql"], f"{safe_name(qid)}.json"))
        if wd_raw and "data" in wd_raw: wd_data = wd_raw["data"]

    # HLTB
    hltb_raw = rw_json(os.path.join(dirs["hltb"], f"{safe_name(search_name)}.json"))
    hours = hltb_raw.get("hours","") if hltb_raw else ""

    # Жанр (спробуємо перекласти або взяти з WD)
    genre_uk = wd_data.get("Genres_UK")
    if not genre_uk:
        store_cat = props.get("Category", "")
        if store_cat and str(store_cat).lower() not in ["game", "gaming", "application"]:
            genre_uk = store_cat
            
    # Аналіз
    tier, score, score_src = analyze_metrics(p, wd_data, genre_uk or "")

    # Описи для модального вікна
    # Формуємо об'єкт для фронтенду
    
    return {
        "id": bid,
        "tier": tier,
        "rating": score,
        "ratingSource": score_src,
        "year": wd_data.get("Year_WD") or (props.get("OriginalReleaseDate") or "")[:4],
        "hours": hours,
        "publisher": lp_en.get("PublisherName") or props.get("PublisherName") or "",
        "developer": lp_en.get("DeveloperName") or lp_uk.get("DeveloperName") or "",
        "image": img_url,
        
        # I18N Data Blocks
        "i18n": {
            "uk": {
                "name": name_uk,
                "genre": genre_uk or "Невідомо",
                "desc": wd_data.get("Description_UK") or desc_uk or "Опис відсутній."
            },
            "en": {
                "name": name_en,
                "genre": props.get("Category", "Unknown"), # Тут можна покращити, якщо парсити WD англійською
                "desc": desc_en or "Description not available."
            }
        },
        
        # Посилання
        "links": {
            "wiki": wd_data.get("WikipediaUrl") or wd_data.get("WikidataUrl"),
            "store": f"https://www.xbox.com/uk-ua/games/store/-/{bid}"
        }
    }

# -----------------------------------------------------------------------------
# Unified Catalog Row Builder
# -----------------------------------------------------------------------------

def _safe_lower(s):
    return (s or "").strip().lower()

def _clean_text(s):
    # Keep this conservative: remove HTML tags & collapse whitespace.
    if not s:
        return ""
    s = re.sub(r"<\s*br\s*/?>", "\n", s, flags=re.I)
    s = re.sub(r"<[^>]+>", " ", s)
    s = re.sub(r"\s+", " ", s).strip()
    return s

def _get_best_image(images):
    """Pick a reasonable image URL from Store 'Images' array."""
    if not images:
        return ""

    preferred = [
        "ImageTile", "Poster", "BoxArt", "SuperHeroArt",
        "Screenshot", "Logo", "Background"
    ]

    best = None
    best_score = -1

    for img in images:
        # Typical keys: ImagePurpose, Purpose, Uri
        purpose = (img.get("ImagePurpose") or img.get("Purpose") or "").strip()
        uri = (img.get("Uri") or "").strip()
        if not uri:
            continue

        # Normalize protocol-less // to https://
        if uri.startswith("//"):
            uri = "https:" + uri

        score = 0
        if purpose in preferred:
            score += (len(preferred) - preferred.index(purpose)) * 10

        # Prefer larger images if width/height present
        w = img.get("Width") or 0
        h = img.get("Height") or 0
        try:
            score += int(w) + int(h)
        except Exception:
            pass

        if score > best_score:
            best_score = score
            best = uri

    return best or ""

def _normalize_genres(product_raw):
    """Return a normalized list of genres/tags from Store data."""
    props = product_raw.get("Properties", {})
    lps = product_raw.get("LocalizedProperties", []) or []

    genres = []

    # 1) Category / Categories
    cat = props.get("Category")
    if cat and str(cat).strip() and str(cat).lower() != "game":
        genres.append(str(cat).strip())

    cats = props.get("Categories")
    if isinstance(cats, list):
        for c in cats:
            if c and str(c).strip() and str(c).lower() != "game":
                genres.append(str(c).strip())

    # 2) Localized 'Genres' if present
    for lp in lps:
        g = lp.get("Genres")
        if isinstance(g, list):
            genres.extend([str(x).strip() for x in g if x])
        elif isinstance(g, str) and g.strip():
            genres.extend([x.strip() for x in g.split(",") if x.strip()])

    # 3) Any tags-like fields (best effort)
    tag_fields = ["Tags", "Tag", "Attributes"]
    for k in tag_fields:
        v = props.get(k)
        if isinstance(v, list):
            genres.extend([str(x).strip() for x in v if x])
        elif isinstance(v, str) and v.strip():
            genres.extend([x.strip() for x in v.split(",") if x.strip()])

    # Deduplicate while preserving order
    out = []
    seen = set()
    for g in genres:
        key = g.lower()
        if key not in seen:
            out.append(g)
            seen.add(key)
    return out

def _is_aaa_indie(product_raw, genres):
    """Return (isAAA, isIndie) based on publisher + heuristics."""
    props = product_raw.get("Properties", {})
    lps = product_raw.get("LocalizedProperties", []) or []
    lp_en = next((x for x in lps if _safe_lower(x.get("Language")) == "en-us"), lps[0] if lps else {})

    publisher = _safe_lower(lp_en.get("PublisherName") or props.get("PublisherName") or "")
    developer = _safe_lower(lp_en.get("DeveloperName") or props.get("DeveloperName") or "")

    text_blob = " ".join([publisher, developer, " ".join([_safe_lower(x) for x in genres or []])])

    is_aaa = any(p in publisher for p in AAA_PUBLISHERS) or any(p in developer for p in AAA_PUBLISHERS)
    is_indie = any(m in text_blob for m in INDIE_MARKERS)

    # If publisher clearly AAA, don't mark as indie unless there is a strong marker.
    if is_aaa and is_indie:
        # keep both if strong indie marker in genres
        strong = ["indie", "independent"]
        if not any(m in text_blob for m in strong):
            is_indie = False

    return bool(is_aaa), bool(is_indie)

def _load_wikidata_enrichment(clean_id, dirs):
    """Load cached Wikidata enrichment produced by gp_collector.download_wiki_data."""
    out = {
        "year": "",
        "desc_uk": "",
        "wiki_url": "",
        "wikidata_url": ""
    }

    try:
        wd_f = os.path.join(dirs.get("wikidata", ""), f"{clean_id}.json")
        if not os.path.exists(wd_f):
            return out

        with open(wd_f, "r", encoding="utf-8") as f:
            qid = (json.load(f) or {}).get("qid")
        if not qid:
            return out

        out["wikidata_url"] = f"https://www.wikidata.org/wiki/{qid}"

        sp_f = os.path.join(dirs.get("wd_sparql", ""), f"{safe_name(qid)}.json")
        if not os.path.exists(sp_f):
            return out

        with open(sp_f, "r", encoding="utf-8") as f:
            data = (json.load(f) or {}).get("data", {}) or {}

        # Keys vary a bit between versions, so be tolerant
        out["year"] = str(data.get("Year_WD") or data.get("Year") or "").strip()
        out["desc_uk"] = _clean_text(data.get("Description_UK") or data.get("desc_uk") or data.get("desc") or "")
        out["wiki_url"] = (data.get("WikiUrl") or data.get("WikipediaUrl") or data.get("wikipedia") or "").strip()

        return out
    except Exception:
        return out

def _load_hltb_enrichment(clean_id, dirs):
    """Load cached HowLongToBeat enrichment produced by gp_collector.download_hltb_data."""
    try:
        h_f = os.path.join(dirs.get("hltb", ""), f"{clean_id}.json")
        if not os.path.exists(h_f):
            return ""
        with open(h_f, "r", encoding="utf-8") as f:
            hours = (json.load(f) or {}).get("hours", "")
        hours = str(hours).strip()
        if hours in ["0", "0.0", ""]:
            return ""
        return hours
    except Exception:
        return ""

def _build_desc_html(store_desc, wiki_desc_uk, links, lang):
    """Create safe HTML description for the catalog."""
    # Keep it simple: paragraphs + optional wiki snippet for uk
    store_desc = _clean_text(store_desc)
    wiki_desc_uk = _clean_text(wiki_desc_uk)

    parts = []
    if store_desc:
        parts.append(f"<p>{html.escape(store_desc)}</p>")
    if lang == "uk" and wiki_desc_uk:
        parts.append("<hr>")
        parts.append(f"<p>{html.escape(wiki_desc_uk)}</p>")

    # Links block
    l = []
    if links.get("store"):
        l.append(f'<a href="{html.escape(links["store"])}" target="_blank" rel="noopener">Store</a>')
    if links.get("wiki"):
        l.append(f'<a href="{html.escape(links["wiki"])}" target="_blank" rel="noopener">Wiki</a>')
    if l:
        parts.append("<div class=\"links\">" + " · ".join(l) + "</div>")

    return "\n".join(parts) if parts else "<p>Опис відсутній.</p>"

def build_catalog_row(bid, dirs, prefer_lang="uk-ua"):
    """Build a complete row from cached product + cached enrichments."""
    # Load cached product
    path = os.path.join(dirs["products"], f"{safe_name(bid)}.json")
    cache = rw_json(path)
    if not cache or "product" not in cache:
        return None

    product_raw = cache["product"]
    props = product_raw.get("Properties", {}) or {}
    lps = product_raw.get("LocalizedProperties", []) or []

    lp_uk = next((x for x in lps if _safe_lower(x.get("Language")) == "uk-ua"), {})
    lp_en = next((x for x in lps if _safe_lower(x.get("Language")) == "en-us"), {})

    # Fallbacks
    if not lp_uk:
        lp_uk = lp_en

    name_uk = lp_uk.get("ProductTitle") or props.get("ProductTitle") or f"UnknownID_{bid}"
    name_en = lp_en.get("ProductTitle") or name_uk
    clean_name_uk = str(name_uk).replace("(PC)", "").replace("(Windows)", "").strip()
    clean_name_en = str(name_en).replace("(PC)", "").replace("(Windows)", "").strip()

    # Genres
    genres = _normalize_genres(product_raw)

    # Year: Store first
    year = str((props.get("OriginalReleaseDate") or "")[:4]).strip()

    # Enrichments
    clean_id = safe_name(clean_name_en or clean_name_uk or bid)
    wd = _load_wikidata_enrichment(clean_id, dirs)
    if wd.get("year"):
        year = wd["year"] or year

    hours = _load_hltb_enrichment(clean_id, dirs)

    # Rating (Microsoft)
    rating = 0.0
    rating_src = ""
    try:
        ms_score = (
            (product_raw.get("MarketProperties") or [{}])[0]
            .get("UsageData", [{}])[0]
            .get("AverageRating", 0)
        )
        if ms_score:
            rating = round(float(ms_score) * 20, 1)
            rating_src = "Microsoft"
    except Exception:
        pass

    # Image
    image_url = _get_best_image(product_raw.get("Images", []) or [])

    # Links
    # Prefer UK store slug if you want; keep a stable store URL pattern.
    links = {
        "store": f"https://www.xbox.com/en-us/games/store/{bid}",
        "wiki": wd.get("wiki_url") or wd.get("wikidata_url") or ""
    }

    # Descriptions
    desc_store_uk = lp_uk.get("ProductDescription") or lp_uk.get("ShortDescription") or ""
    desc_store_en = lp_en.get("ProductDescription") or lp_en.get("ShortDescription") or desc_store_uk

    html_uk = _build_desc_html(desc_store_uk, wd.get("desc_uk", ""), links, "uk")
    html_en = _build_desc_html(desc_store_en, "", links, "en")

    # AAA / Indie flags
    isAAA, isIndie = _is_aaa_indie(product_raw, genres)

    # Tier / smart metrics (best-effort)
    try:
        tier, smart_score, smart_src = analyze_metrics(product_raw, {"Score": 0, "Count": 0}, ", ".join(genres))
    except Exception:
        tier, smart_score, smart_src = ("Standard", 0.0, "")

    return {
        "id": bid,
        "name": clean_name_uk,
        "genres": genres,
        "tier": tier,
        "rating": rating,
        "ratingSource": rating_src,
        "smartScore": smart_score,
        "smartScoreSource": smart_src,
        "year": year,
        "hours": hours,
        "publisher": props.get("PublisherName", ""),
        "developer": props.get("DeveloperName", ""),
        "isAAA": isAAA,
        "isIndie": isIndie,
        "image": image_url,
        "i18n": {
            "uk": {"name": clean_name_uk, "genre": (genres[0] if genres else "Unknown"), "desc": html_uk},
            "en": {"name": clean_name_en, "genre": (genres[0] if genres else "Unknown"), "desc": html_en},
        },
        "links": links,
    }
