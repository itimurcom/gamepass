from __future__ import annotations

from typing import Dict, List

from .config import Config
from .net import http_get_json
from .url import build_url

DISPLAYCATALOG_URL = "https://displaycatalog.mp.microsoft.com/v7.0/products"


def fetch_products(cfg: Config, big_ids: List[str]) -> List[Dict[str, object]]:
    url = build_url(
        DISPLAYCATALOG_URL,
        {"bigIds": ",".join(big_ids), "market": cfg.market, "languages": cfg.language},
    )
    payload = http_get_json(url, cfg.timeout_s)
    products = payload.get("Products", []) if isinstance(payload, dict) else []
    return products if isinstance(products, list) else []
