# Seed URLs for OLX panel tracking (RTX 4070)

- Generated: 2025-12-17 17:28:18 EET
- Unique URLs: 200
- Sources:
  - /mnt/data/olx_rtx4070_200_cleaned_listings.csv
  - /mnt/data/olx_rtx4070_allmodels_200_listings.csv
  - /mnt/data/olx_rtx4070_removed_outliers.csv

Usage:
```bash
python olx_panel_tracker.py seed --db olx_panel.sqlite3 --urls-file seed_urls_rtx4070.txt
```
