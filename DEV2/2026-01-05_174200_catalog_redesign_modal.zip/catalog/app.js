(function () {
  "use strict";

  const $ = (id) => document.getElementById(id);

  const state = {
    lang: "EN",         // EN | UA
    theme: "light",     // light | dark
    view: "table",      // table | tiles
    q: "",
    sortKey: "name",    // name | publisher | year
    sortDir: "asc",     // asc | desc
    page: 1,
    pageSize: 48,
  };

  function safeText(v) {
    return (v === null || v === undefined) ? "" : String(v);
  }

  function getCatalog() {
    return window.GAMEPASS_CATALOG || { EN: {}, UA: {} };
  }

  function getLangMap() {
    const cat = getCatalog();
    return cat[state.lang] || {};
  }

  function firstLocalized(product) {
    const lp = product && product.LocalizedProperties;
    if (Array.isArray(lp) && lp.length > 0 && typeof lp[0] === "object" && lp[0]) return lp[0];
    return null;
  }

  function getTitle(product, gameid) {
    const lp = firstLocalized(product);
    return safeText((lp && (lp.ProductTitle || lp.Title)) || product.ProductTitle || gameid);
  }

  function getPublisher(product) {
    return safeText(product.PublisherName || product.Publisher || "");
  }

  function getReleaseDateRaw(product) {
    const mp = product && product.MarketProperties;
    const d = (Array.isArray(mp) && mp[0] && mp[0].OriginalReleaseDate) ? mp[0].OriginalReleaseDate : (product.OriginalReleaseDate || "");
    return safeText(d || "");
  }

  function getReleaseYear(product) {
    const raw = getReleaseDateRaw(product);
    const m = raw.match(/^\d{4}/);
    return m ? m[0] : "";
  }

  function getDescription(product) {
    const lp = firstLocalized(product);
    return safeText((lp && (lp.ProductDescription || lp.Description)) || "");
  }

  function pickImageUrl(product) {
    const lp = firstLocalized(product);
    const imgs = lp && lp.Images;
    if (!Array.isArray(imgs)) return "";

    const preferredPurposes = [
      // Posters first (2/3)
      "Poster",
      "BoxArt",
      "BrandedKeyArt",
      // Then wide hero-like
      "SuperHeroArt",
      "Hero",
      // Fallbacks
      "FeaturePromotionalSquareArt",
      "Screenshot",
      "Icon",
      "Logo",
    ];

    for (const purpose of preferredPurposes) {
      const hit = imgs.find((x) => x && x.ImagePurpose === purpose && x.Uri);
      if (hit) return hit.Uri;
    }

    const any = imgs.find((x) => x && x.Uri);
    return any ? any.Uri : "";
  }

  function matchesQuery(title, publisher, q) {
    if (!q) return true;
    const s = (title + " " + publisher).toLowerCase();
    return s.includes(q.toLowerCase());
  }

  function setTheme(theme) {
    state.theme = theme;
    document.documentElement.setAttribute("data-theme", theme === "dark" ? "dark" : "light");
    try { localStorage.setItem("gp_theme", theme); } catch (_) {}
  }

  function toggleTheme() {
    setTheme(state.theme === "dark" ? "light" : "dark");
  }

  function setLang(lang) {
    state.lang = lang;
    state.page = 1;
    $("btnLang").textContent = lang;
    try { localStorage.setItem("gp_lang", lang); } catch (_) {}
  }

  function toggleLang() {
    setLang(state.lang === "EN" ? "UA" : "EN");
    renderAll();
  }

  function setView(view) {
    state.view = view;
    $("btnTable").classList.toggle("active", view === "table");
    $("btnTiles").classList.toggle("active", view === "tiles");
    $("tableView").style.display = (view === "table") ? "" : "none";
    $("tilesView").style.display = (view === "tiles") ? "" : "none";
    renderAll();
  }

  function setSort(key) {
    if (state.sortKey === key) {
      state.sortDir = (state.sortDir === "asc") ? "desc" : "asc";
    } else {
      state.sortKey = key;
      state.sortDir = "asc";
    }
    renderAll();
  }

  function getEntriesFilteredSorted() {
    const map = getLangMap();
    const entries = Object.entries(map);

    const out = [];
    for (const [gameid, product] of entries) {
      const title = getTitle(product, gameid);
      const pub = getPublisher(product);
      if (!matchesQuery(title, pub, state.q)) continue;

      out.push({
        gameid,
        product,
        title,
        pub,
        year: getReleaseYear(product),
      });
    }

    const dir = state.sortDir === "asc" ? 1 : -1;
    out.sort((a, b) => {
      if (state.sortKey === "publisher") return a.pub.localeCompare(b.pub) * dir;
      if (state.sortKey === "year") return (a.year.localeCompare(b.year) || a.title.localeCompare(b.title)) * dir;
      return a.title.localeCompare(b.title) * dir;
    });

    return out;
  }

  function paginate(items) {
    const total = items.length;
    const pages = Math.max(1, Math.ceil(total / state.pageSize));
    if (state.page > pages) state.page = pages;

    const start = (state.page - 1) * state.pageSize;
    const end = start + state.pageSize;
    return { pageItems: items.slice(start, end), total, pages };
  }

  function renderPagination(pages) {
    const wrap = $("pagination");
    wrap.innerHTML = "";
    if (pages <= 1) return;

    const makeBtn = (label, page, active) => {
      const b = document.createElement("button");
      b.className = "pg-btn" + (active ? " pg-active" : "");
      b.textContent = label;
      b.addEventListener("click", () => { state.page = page; renderAll(); });
      return b;
    };

    // Windowed pagination
    const windowSize = 9;
    const half = Math.floor(windowSize / 2);
    let start = Math.max(1, state.page - half);
    let end = Math.min(pages, start + windowSize - 1);
    start = Math.max(1, end - windowSize + 1);

    wrap.appendChild(makeBtn("«", 1, false));
    wrap.appendChild(makeBtn("‹", Math.max(1, state.page - 1), false));

    for (let p = start; p <= end; p++) {
      wrap.appendChild(makeBtn(String(p), p, p === state.page));
    }

    wrap.appendChild(makeBtn("›", Math.min(pages, state.page + 1), false));
    wrap.appendChild(makeBtn("»", pages, false));
  }

  function renderTable(itemsPage) {
    const tbody = $("tbody");
    tbody.innerHTML = "";

    for (const it of itemsPage) {
      const tr = document.createElement("tr");

      const tdImg = document.createElement("td");
      const img = document.createElement("img");
      img.className = "cover";
      img.alt = it.title;
      const url = pickImageUrl(it.product);
      if (url) {
        img.src = url;
      } else {
        img.classList.add("no-avatar");
        img.removeAttribute("src");
      }
      tdImg.appendChild(img);

      const tdName = document.createElement("td");
      tdName.textContent = it.title;

      const tdPub = document.createElement("td");
      tdPub.textContent = it.pub || "—";

      const tdYear = document.createElement("td");
      tdYear.textContent = it.year || "—";

      const tdAct = document.createElement("td");
      const btn = document.createElement("button");
      btn.className = "btn-read";
      btn.type = "button";
      btn.textContent = "Details";
      btn.addEventListener("click", (e) => { e.stopPropagation(); openModal(it.gameid); });
      tdAct.appendChild(btn);

      tr.appendChild(tdImg);
      tr.appendChild(tdName);
      tr.appendChild(tdPub);
      tr.appendChild(tdYear);
      tr.appendChild(tdAct);

      tr.addEventListener("click", () => openModal(it.gameid));
      tbody.appendChild(tr);
    }
  }

  function renderTiles(itemsPage) {
    const tiles = $("tiles");
    tiles.innerHTML = "";

    for (const it of itemsPage) {
      const tile = document.createElement("div");
      tile.className = "tile";
      tile.tabIndex = 0;

      const img = document.createElement("img");
      const url = pickImageUrl(it.product);
      if (url) img.src = url;
      else img.src = (state.theme === "dark") ? "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyMDAiIGhlaWdodD0iMzAwIiB2aWV3Qm94PSIwIDAgMjAwIDMwMCI+PHJlY3Qgd2lkdGg9IjIwMCIgaGVpZ2h0PSIzMDAiIGZpbGw9IiMyYzJjMmUiLz48dGV4dCB4PSI1MCUiIHk9IjUwJSIgZG9taW5hbnQtYmFzZWxpbmU9Im1pZGRsZSIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZm9udC1mYW1pbHk9InNhbnMtc2VyaWYiIGZvbnQtc2l6ZT0iMjAiIGZvbnQtd2VpZ2h0PSJib2xkIiBmaWxsPSIjNDQ0Ij5OTyBJTUFHRTwvdGV4dD48L3N2Zz4="
                               : "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyMDAiIGhlaWdodD0iMzAwIiB2aWV3Qm94PSIwIDAgMjAwIDMwMCI+PHJlY3Qgd2lkdGg9IjIwMCIgaGVpZ2h0PSIzMDAiIGZpbGw9IiNmMmYyZjciLz48dGV4dCB4PSI1MCUiIHk9IjUwJSIgZG9taW5hbnQtYmFzZWxpbmU9Im1pZGRsZSIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZm9udC1hbmNob3I9Im1pZGRsZSIgZm9udC1mYW1pbHk9InNhbnMtc2VyaWYiIGZvbnQtc2l6ZT0iMjAiIGZvbnQtd2VpZ2h0PSJib2xkIiBmaWxsPSIjMWMxYzFlIj5OTyBJTUFHRTwvdGV4dD48L3N2Zz4=";
      img.alt = it.title;

      const title = document.createElement("div");
      title.className = "tile-title";
      title.textContent = it.title;

      const sub = document.createElement("div");
      sub.className = "tile-sub";
      sub.textContent = [it.pub, it.year].filter(Boolean).join(" • ") || "—";

      tile.appendChild(img);
      tile.appendChild(title);
      tile.appendChild(sub);

      tile.addEventListener("click", () => openModal(it.gameid));
      tile.addEventListener("keypress", (e) => { if (e.key === "Enter" || e.key === " ") openModal(it.gameid); });

      tiles.appendChild(tile);
    }
  }

  function openModal(gameid) {
    const map = getLangMap();
    const product = map[gameid];
    if (!product) return;

    const title = getTitle(product, gameid);
    const pub = getPublisher(product);
    const rawDate = getReleaseDateRaw(product);
    const desc = getDescription(product);
    const imgUrl = pickImageUrl(product);

    $("modalTitle").textContent = title;

    const body = document.createElement("div");

    const hero = document.createElement("div");
    hero.className = "game-hero";

    const poster = document.createElement("img");
    poster.className = "game-poster";
    poster.alt = title;
    if (imgUrl) poster.src = imgUrl;
    else {
      // use CSS placeholder via inline SVG to keep layout stable
      poster.src = (state.theme === "dark") ? "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyMDAiIGhlaWdodD0iMzAwIiB2aWV3Qm94PSIwIDAgMjAwIDMwMCI+PHJlY3Qgd2lkdGg9IjIwMCIgaGVpZ2h0PSIzMDAiIGZpbGw9IiMyYzJjMmUiLz48dGV4dCB4PSI1MCUiIHk9IjUwJSIgZG9taW5hbnQtYmFzZWxpbmU9Im1pZGRsZSIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZm9udC1mYW1pbHk9InNhbnMtc2VyaWYiIGZvbnQtc2l6ZT0iMjAiIGZvbnQtd2VpZ2h0PSJib2xkIiBmaWxsPSIjNDQ0Ij5OTyBJTUFHRTwvdGV4dD48L3N2Zz4="
                                : "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyMDAiIGhlaWdodD0iMzAwIiB2aWV3Qm94PSIwIDAgMjAwIDMwMCI+PHJlY3Qgd2lkdGg9IjIwMCIgaGVpZ2h0PSIzMDAiIGZpbGw9IiNmMmYyZjciLz48dGV4dCB4PSI1MCUiIHk9IjUwJSIgZG9taW5hbnQtYmFzZWxpbmU9Im1pZGRsZSIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZm9udC1mYW1pbHk9InNhbnMtc2VyaWYiIGZvbnQtc2l6ZT0iMjAiIGZvbnQtd2VpZ2h0PSJib2xkIiBmaWxsPSIjMWMxYzFlIj5OTyBJTUFHRTwvdGV4dD48L3N2Zz4=";
    }

    const info = document.createElement("div");
    info.className = "game-info";

    const t = document.createElement("div");
    t.className = "game-title";
    t.textContent = title;

    const sub = document.createElement("div");
    sub.className = "game-sub";
    sub.textContent = [pub, rawDate].filter(Boolean).join(" • ");

    const kv = document.createElement("div");
    kv.className = "kv";
    const mkTag = (txt) => {
      const s = document.createElement("span");
      s.className = "tag";
      s.textContent = txt;
      return s;
    };
    kv.appendChild(mkTag("Lang: " + state.lang));
    kv.appendChild(mkTag("ID: " + gameid));
    const yr = getReleaseYear(product);
    if (yr) kv.appendChild(mkTag("Year: " + yr));

    const descEl = document.createElement("div");
    descEl.className = "desc-text";
    descEl.textContent = desc || "(No description in this locale)";

    info.appendChild(t);
    info.appendChild(sub);
    info.appendChild(kv);

    hero.appendChild(poster);
    hero.appendChild(info);

    body.appendChild(hero);
    body.appendChild(descEl);

    const modalContent = $("modalContent");
    modalContent.innerHTML = "";
    modalContent.appendChild(body);

    const overlay = $("modalOverlay");
    overlay.classList.add("open");
    overlay.setAttribute("aria-hidden", "false");

    // Focus close for accessibility
    $("modalClose").focus();
  }

  function closeModal() {
    const overlay = $("modalOverlay");
    overlay.classList.remove("open");
    overlay.setAttribute("aria-hidden", "true");
  }

  function renderAll() {
    const all = getEntriesFilteredSorted();
    const { pageItems, total, pages } = paginate(all);

    $("countTxt").value = `${state.lang}: ${total} games`;

    if (state.view === "table") renderTable(pageItems);
    else renderTiles(pageItems);

    renderPagination(pages);
  }

  function initSortHandlers() {
    // Table headers
    document.querySelectorAll("th.sortable").forEach((th) => {
      th.addEventListener("click", () => {
        const key = th.getAttribute("data-key");
        if (key) setSort(key);
      });
    });
  }

  function initFab() {
    const fs = document.querySelector(".float-settings");
    $("fabMain").addEventListener("click", () => {
      fs.classList.toggle("open");
    });
    // Close on outside click (but ignore clicks inside the floating panel)
    document.addEventListener("click", (e) => {
      if (!fs.contains(e.target)) fs.classList.remove("open");
    });
  }

  function initModalHandlers() {
    $("modalClose").addEventListener("click", closeModal);
    $("modalOverlay").addEventListener("click", (e) => {
      if (e.target === $("modalOverlay")) closeModal();
    });
    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape") closeModal();
    });
  }

  function init() {
    // Restore preferences
    try {
      const th = localStorage.getItem("gp_theme");
      if (th === "dark" || th === "light") state.theme = th;
      const lg = localStorage.getItem("gp_lang");
      if (lg === "EN" || lg === "UA") state.lang = lg;
    } catch (_) {}

    setTheme(state.theme);
    $("btnLang").textContent = state.lang;

    // Controls
    $("btnTable").addEventListener("click", () => setView("table"));
    $("btnTiles").addEventListener("click", () => setView("tiles"));

    $("searchTxt").addEventListener("input", (e) => {
      state.q = e.target.value || "";
      state.page = 1;
      renderAll();
    });

    $("btnReset").addEventListener("click", () => {
      state.q = "";
      $("searchTxt").value = "";
      state.sortKey = "name";
      state.sortDir = "asc";
      state.page = 1;
      renderAll();
    });

    $("btnTheme").addEventListener("click", () => {
      toggleTheme();
      renderAll();
    });

    $("btnLang").addEventListener("click", toggleLang);

    initSortHandlers();
    initFab();
    initModalHandlers();

    renderAll();
  }

  init();
})();
