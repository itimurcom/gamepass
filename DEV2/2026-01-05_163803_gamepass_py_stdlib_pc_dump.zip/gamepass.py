#!/usr/bin/env python3
"""
PC Game Pass catalog dumper (EN/US only) - stdlib only

Result:
  - Creates .cash directory (default) with one raw Microsoft Store product JSON per game.
  - Writes meta files under .cash/_meta/

Notes:
  - Source list (SIGL) for PC Game Pass: fdd9e2a7-0fee-49f6-ad69-4354098401ff
  - Uses only Python standard library (urllib).
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Set, Tuple


SIGL_URL = "https://catalog.gamepass.com/sigls/v2"
DISPLAYCATALOG_URL = "https://displaycatalog.mp.microsoft.com/v7.0/products"

PC_GAMEPASS_SIGL = "fdd9e2a7-0fee-49f6-ad69-4354098401ff"

DEFAULT_HEADERS = {
    "User-Agent": "gamepass-catalog-dumper/1.0",
    "Accept": "application/json",
}


@dataclass(frozen=True)
class Config:
    market: str
    language: str
    out_dir: Path
    sigl_id: str
    batch_size: int
    sleep_s: float
    timeout_s: float
    retries: int


def _stable_json_bytes(obj: Any) -> bytes:
    # Stable serialization for hashing / change detection
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")


def _sha256_bytes(data: bytes) -> str:
    h = hashlib.sha256()
    h.update(data)
    return h.hexdigest()


def _read_file_bytes(path: Path) -> Optional[bytes]:
    try:
        return path.read_bytes()
    except FileNotFoundError:
        return None


def _write_atomic_bytes(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_bytes(data)
    os.replace(tmp, path)


def _write_json_atomic(path: Path, obj: Any, pretty: bool = True) -> None:
    if pretty:
        data = json.dumps(obj, ensure_ascii=False, indent=2).encode("utf-8")
    else:
        data = _stable_json_bytes(obj)
    _write_atomic_bytes(path, data)


def _log(msg: str) -> None:
    print(msg, file=sys.stderr)


def _build_url(base: str, params: Dict[str, str]) -> str:
    qs = urllib.parse.urlencode(params)
    return f"{base}?{qs}"


def _http_get_json(url: str, *, timeout_s: float, headers: Dict[str, str]) -> Any:
    req = urllib.request.Request(url, headers=headers, method="GET")
    with urllib.request.urlopen(req, timeout=timeout_s) as resp:
        raw = resp.read()
    return json.loads(raw.decode("utf-8"))


def _get_json_with_retries(
    url: str,
    *,
    timeout_s: float,
    headers: Dict[str, str],
    retries: int = 4,
    base_backoff_s: float = 0.75,
) -> Any:
    last_exc: Optional[Exception] = None

    for attempt in range(retries + 1):
        try:
            return _http_get_json(url, timeout_s=timeout_s, headers=headers)
        except urllib.error.HTTPError as e:
            last_exc = e
            code = getattr(e, "code", None)
            retryable = code in (429, 500, 502, 503, 504)
            if (not retryable) or attempt >= retries:
                raise
            sleep_for = base_backoff_s * (2 ** attempt)
            _log(f"[retry] GET {url} HTTP {code} attempt={attempt+1}/{retries} sleep={sleep_for:.2f}s")
            time.sleep(sleep_for)
        except (urllib.error.URLError, TimeoutError, ValueError) as e:
            last_exc = e
            if attempt >= retries:
                break
            sleep_for = base_backoff_s * (2 ** attempt)
            _log(f"[retry] GET {url} attempt={attempt+1}/{retries} sleep={sleep_for:.2f}s error={e}")
            time.sleep(sleep_for)

    assert last_exc is not None
    raise last_exc


def fetch_sigl_big_ids(cfg: Config) -> Tuple[Set[str], Dict[str, Any]]:
    url = _build_url(SIGL_URL, {"id": cfg.sigl_id, "market": cfg.market, "language": cfg.language})
    payload = _get_json_with_retries(url, timeout_s=cfg.timeout_s, headers=DEFAULT_HEADERS, retries=cfg.retries)

    products = payload.get("products", [])
    big_ids: Set[str] = set()
    for p in products:
        if isinstance(p, dict):
            pid = p.get("id")
            if isinstance(pid, str) and pid:
                big_ids.add(pid)

    meta = {
        "sigl_id": cfg.sigl_id,
        "market": cfg.market,
        "language": cfg.language,
        "count": len(big_ids),
        "fetched_at_unix": int(time.time()),
        "raw": payload,
    }
    return big_ids, meta


def fetch_products_batch(cfg: Config, big_ids: List[str]) -> List[Dict[str, Any]]:
    url = _build_url(
        DISPLAYCATALOG_URL,
        {"bigIds": ",".join(big_ids), "market": cfg.market, "languages": cfg.language},
    )
    payload = _get_json_with_retries(url, timeout_s=cfg.timeout_s, headers=DEFAULT_HEADERS, retries=cfg.retries)

    products = payload.get("Products") or payload.get("products") or []
    if not isinstance(products, list):
        return []

    out: List[Dict[str, Any]] = []
    for p in products:
        if isinstance(p, dict) and p.get("ProductId"):
            out.append(p)
    return out


def chunked(seq: List[str], size: int) -> Iterable[List[str]]:
    for i in range(0, len(seq), size):
        yield seq[i : i + size]


def write_product_if_changed(out_dir: Path, product: Dict[str, Any]) -> bool:
    product_id = product.get("ProductId")
    if not isinstance(product_id, str) or not product_id:
        return False

    path = out_dir / f"{product_id}.json"

    new_pretty = json.dumps(product, ensure_ascii=False, indent=2).encode("utf-8")
    new_hash = _sha256_bytes(_stable_json_bytes(product))

    old_bytes = _read_file_bytes(path)
    if old_bytes is not None:
        try:
            old_obj = json.loads(old_bytes.decode("utf-8"))
            old_hash = _sha256_bytes(_stable_json_bytes(old_obj))
            if old_hash == new_hash:
                return False
        except Exception:
            # If the old file is corrupted/unparseable, overwrite it
            pass

    _write_atomic_bytes(path, new_pretty)
    return True


def run(cfg: Config) -> int:
    cfg.out_dir.mkdir(parents=True, exist_ok=True)
    meta_dir = cfg.out_dir / "_meta"
    meta_dir.mkdir(parents=True, exist_ok=True)

    _log(f"[sigl] Fetching PC Game Pass list: sigl={cfg.sigl_id} market={cfg.market} lang={cfg.language}")
    big_ids, sigl_meta = fetch_sigl_big_ids(cfg)
    _write_json_atomic(meta_dir / f"sigl_{cfg.market}_{cfg.language}.json", sigl_meta)

    ids_sorted = sorted(big_ids)
    _log(f"[sigl] unique bigIds: {len(ids_sorted)}")

    written = 0
    unchanged = 0
    fetched = 0

    for batch in chunked(ids_sorted, cfg.batch_size):
        products = fetch_products_batch(cfg, batch)
        fetched += len(products)

        for p in products:
            changed = write_product_if_changed(cfg.out_dir, p)
            if changed:
                written += 1
            else:
                unchanged += 1

        time.sleep(cfg.sleep_s)

    run_meta = {
        "market": cfg.market,
        "language": cfg.language,
        "sigl_id": cfg.sigl_id,
        "unique_bigIds": len(ids_sorted),
        "products_fetched": fetched,
        "files_written": written,
        "files_unchanged": unchanged,
        "timestamp_unix": int(time.time()),
    }
    _write_json_atomic(meta_dir / "run.json", run_meta)

    _log(f"[done] fetched={fetched} written={written} unchanged={unchanged}")
    return 0


def build_arg_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="Dump PC Game Pass catalog to .cash (stdlib-only, EN/US).")
    p.add_argument("--out", default=".cash", help="Output directory (default: .cash)")
    p.add_argument("--market", default="US", help="Market (default: US)")
    p.add_argument("--lang", default="en-us", help="Language (default: en-us)")
    p.add_argument("--sigl", default=PC_GAMEPASS_SIGL, help="SIGL id (default: PC Game Pass)")
    p.add_argument("--batch", type=int, default=100, help="Batch size for bigIds (default: 100)")
    p.add_argument("--sleep", type=float, default=0.2, help="Sleep between requests in seconds (default: 0.2)")
    p.add_argument("--timeout", type=float, default=30.0, help="HTTP timeout in seconds (default: 30)")
    p.add_argument("--retries", type=int, default=4, help="Retries for transient errors (default: 4)")
    return p


def main() -> int:
    args = build_arg_parser().parse_args()
    cfg = Config(
        market=args.market,
        language=args.lang,
        out_dir=Path(args.out),
        sigl_id=args.sigl,
        batch_size=args.batch,
        sleep_s=args.sleep,
        timeout_s=args.timeout,
        retries=args.retries,
    )
    return run(cfg)


if __name__ == "__main__":
    raise SystemExit(main())
