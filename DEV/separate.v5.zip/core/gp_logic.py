# gp_logic.py
# Логіка обробки даних (v5.1 Clean & Smart)

import os
import json
import re

# --- КОНСТАНТИ ---
# Розширений список видавців для визначення AAA
AAA_PUBLISHERS = [
    "xbox game studios", "bethesda", "electronic arts", "ea", "ubisoft", 
    "activision", "blizzard", "rockstar", "2k", "capcom", "square enix", 
    "bandai namco", "sega", "wb games", "sony", "cd projekt", "take-two",
    "konami", "riot games", "bungie", "epic games"
]

# Слова-маркери, які вказують, що це НЕ AAA гра, навіть якщо видавець відомий
INDIE_MARKERS = ["indie", "independent", "аркади", "arcade", "platformer", "puzzle"]

# --- УТИЛІТИ ---
def safe_name(s):
    return "".join(c for c in (s or "").lower() if c.isalnum() or c in "-_")[:180] or "x"

def rw_json(path, data=None):
    if data is None: # Read
        if os.path.exists(path):
            try:
                with open(path, "r", encoding="utf-8") as f:
                    content = json.load(f)
                    if not content: return None 
                    return content
            except (json.JSONDecodeError, OSError):
                return None
        return None
    else: # Write
        tmp = path + ".tmp"
        try:
            with open(tmp, "w", encoding="utf-8") as f: 
                json.dump(data, f, ensure_ascii=False, indent=2)
            os.replace(tmp, path)
        except Exception as e:
            print(f"[ERROR] Не вдалося записати {path}: {e}")

# --- БІЗНЕС-ЛОГІКА ---

def analyze_metrics(product_raw, wikidata_data, genres_str):
    """
    Визначає Tier (AAA/Indie) та Розумний Рейтинг.
    """
    props = product_raw.get("Properties", {})
    market_props = product_raw.get("MarketProperties", [])
    
    # 1. ВИДАВЕЦЬ
    lps = product_raw.get("LocalizedProperties", [])
    lp = next((x for x in lps if x.get("Language","").lower() in ["en-us", "uk-ua"]), lps[0] if lps else {})
    publisher = (lp.get("PublisherName") or props.get("PublisherName") or "").lower()
    
    # 2. РОЗМІР (ГБ)
    max_size_gb = 0
    if product_raw.get("DisplaySkuAvailabilities"):
        for sku_avail in product_raw["DisplaySkuAvailabilities"]:
            pkg = sku_avail.get("Sku", {}).get("Properties", {}).get("Packages", [])
            if pkg:
                size_bytes = pkg[0].get("MaxDownloadFileSizeInBytes", 0)
                max_size_gb = max(max_size_gb, size_bytes / (1024**3))

    # 3. ЕВРИСТИКА TIER
    is_aaa_publisher = any(p in publisher for p in AAA_PUBLISHERS)
    is_huge_game = max_size_gb > 45 # Якщо гра важить більше 45 ГБ, це майже завжди AAA
    
    # Перевірка на інді-маркери в жанрах (запобіжник)
    is_indie_genre = any(m in genres_str.lower() for m in INDIE_MARKERS)
    
    tier = "Indie/AA"
    if (is_aaa_publisher or is_huge_game) and not is_indie_genre:
        tier = "AAA"
    
    # 4. РЕЙТИНГ (Smart Score)
    ms_score = 0
    ms_count = 0
    # Шукаємо оцінки користувачів Xbox
    for mp in market_props:
        usage = mp.get("UsageData", [])
        for u in usage:
            if u.get("AggregateTimeSpan") == "AllTime":
                ms_score = u.get("AverageRating", 0)
                ms_count = u.get("RatingCount", 0)
                break
        if ms_count > 0: break
    
    # Оцінка критиків з Wikidata (Metacritic/OpenCritic тощо)
    wd_score_raw = wikidata_data.get("Rating", 0)
    wd_score = 0
    try:
        wd_val = float(str(wd_score_raw).split("/")[0])
        if wd_val <= 5: wd_score = wd_val * 20
        elif wd_val <= 10: wd_score = wd_val * 10
        else: wd_score = wd_val
    except: pass

    # Формула Байєса: (v / (v+m)) * R + (m / (v+m)) * C
    final_score = 0
    if ms_count > 0:
        R = ms_score * 20
        v = ms_count
        m = 50 # поріг довіри
        C = 75 # середній бал
        final_score = (v / (v + m)) * R + (m / (v + m)) * C
    elif wd_score > 0:
        final_score = wd_score
    
    score_src = f"{ms_count} (Xbox)" if ms_count else ("Wiki" if wd_score > 0 else "")
    
    return tier, round(final_score, 1), score_src

def get_product_data(bid, dirs, lang):
    path = os.path.join(dirs["products"], f"{safe_name(bid)}.json")
    cache = rw_json(path)
    if not cache or "product" not in cache: return None 
        
    p = cache["product"]
    lps = p.get("LocalizedProperties", [])
    lp = next((x for x in lps if x.get("Language","").lower() == lang), lps[0] if lps else {})
    props = p.get("Properties", {})
    
    # Картинка
    imgs = lp.get("Images", [])
    if not imgs and p.get("DisplaySkuAvailabilities"):
        skus = p.get("DisplaySkuAvailabilities")[0].get("Sku", {}).get("LocalizedProperties", [])
        if skus: imgs = skus[0].get("Images", [])
    img_url = next((i.get("Uri") for i in imgs if i.get("ImagePurpose") in ["Poster", "BoxArt"]), imgs[0].get("Uri") if imgs else "")
    if img_url and img_url.startswith("//"): img_url = "https:" + img_url

    name = lp.get("ProductTitle") or p.get("ProductTitle") or ""
    if not name: return None

    search_name = name.replace("(Game Preview)", "").replace("(PC)", "").strip()

    # Збір Wikidata
    wd_cache_name = rw_json(os.path.join(dirs["wikidata"], f"{safe_name(search_name)}.json"))
    qid = wd_cache_name.get("qid") if wd_cache_name else None
    wd_data = {}
    if qid:
        wd_raw = rw_json(os.path.join(dirs["wd_sparql"], f"{safe_name(qid)}.json"))
        if wd_raw and "data" in wd_raw: wd_data = wd_raw["data"]

    # Збір HLTB
    hltb_raw = rw_json(os.path.join(dirs["hltb"], f"{safe_name(search_name)}.json"))
    hours = hltb_raw.get("hours","") if hltb_raw else ""

    # Жанри
    genre_final = wd_data.get("Genres_UK")
    if not genre_final:
        store_cat = props.get("Category", "")
        if store_cat and str(store_cat).lower() not in ["game", "gaming", "application"]:
            genre_final = store_cat
    
    # Метрики (Tier, Rating) - Бюджет прибрано
    tier, score, score_src = analyze_metrics(p, wd_data, genre_final or "")

    # ОПИСИ (Структуровані блоки)
    desc_sources = []
    
    # 1. Wiki
    if wd_data.get("Description_UK"):
        desc_sources.append({
            "source": "Wikipedia",
            "text": wd_data.get("Description_UK"),
            "link": wd_data.get("WikipediaUrl") or wd_data.get("WikidataUrl")
        })
    
    # 2. Microsoft Store (ShortDescription)
    store_desc = lp.get("ShortDescription") or lp.get("ProductDescription")
    if store_desc:
        clean_desc = re.sub(r'<[^>]+>', '', store_desc).strip()
        # Додаємо, якщо цей текст не дублює Wiki
        if clean_desc and (not wd_data.get("Description_UK") or clean_desc[:50] != wd_data.get("Description_UK")[:50]):
             desc_sources.append({
                "source": "Microsoft Store",
                "text": clean_desc,
                "link": f"https://www.xbox.com/uk-ua/games/store/-/{bid}"
            })

    # Генерація "Брифа" (перше речення з першого джерела)
    brief = ""
    if desc_sources:
        first_text = desc_sources[0]["text"]
        # Спробуємо взяти перше речення
        match = re.match(r'([^.!?]+[.!?])', first_text)
        brief = match.group(0) if match else (first_text[:120] + "...")

    return {
        "id": bid,
        "name": name,
        "genre": genre_final or "",
        "tier": tier,
        "rating": score,
        "ratingSource": score_src,
        "year": wd_data.get("Year_WD") or (props.get("OriginalReleaseDate") or "")[:4],
        "hours": hours,
        "publisher": lp.get("PublisherName",""),
        "developer": lp.get("DeveloperName",""),
        "image": img_url,
        
        # Нова структура описів
        "brief": brief,
        "descriptions": desc_sources 
    }