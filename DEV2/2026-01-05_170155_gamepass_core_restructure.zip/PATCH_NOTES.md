# Patch Notes: core restructure

Goal:
- Move logic into new core/* files as requested:
  - SIGL fetching -> core/gp_sigl.py
  - Config -> core/gp_config.py
  - Network requests -> core/gp_net.py
  - Terminal output + progress bar -> core/gp_terminal.py
  - Everything else -> core/core.py
- Update gamepass.py imports accordingly
- Remove old/empty files (manual delete list below)

Files added/updated in this patch:
- gamepass.py (+x)
- core/__init__.py
- core/gp_config.py
- core/gp_net.py
- core/gp_terminal.py
- core/gp_sigl.py
- core/core.py

Files to DELETE from your working tree after applying this patch (these are replaced by the new gp_* modules):
- core/config.py
- core/net.py
- core/url.py
- core/sigl.py
- core/displaycatalog.py
- core/fs.py
- core/utils.py
- core/logging.py

Why delete:
- Their functionality has been moved into the new requested files; keeping them would be dead/duplicate code and cause confusion.
