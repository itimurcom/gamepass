#!/usr/bin/env python3
"""
OLX panel analyzer (single-file):

- Reads the SQLite DB produced by olx_panel_tracker.py
- Builds Kaplan–Meier survival curves by relative START price bins
  (event = listing disappeared from OLX; censored = still active)
- Exports a single-file interactive HTML dashboard (Plotly)

No external survival libraries required.
"""

from __future__ import annotations

import argparse
import datetime as dt
import math
import sqlite3
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Tuple, Optional
import json


def parse_iso_z(s: str) -> dt.datetime:
    if s.endswith("Z"):
        s = s[:-1]
    return dt.datetime.fromisoformat(s)


def days_between(a_iso: str, b_iso: str) -> int:
    a = parse_iso_z(a_iso)
    b = parse_iso_z(b_iso)
    return max(0, int((b - a).total_seconds() // 86400))


@dataclass
class Listing:
    listing_id: str
    first_seen_utc: str
    last_seen_utc: str
    is_active: int
    first_price_uah: Optional[float]


def connect(db_path: str) -> sqlite3.Connection:
    con = sqlite3.connect(db_path)
    con.row_factory = sqlite3.Row
    return con


def load_listings(con: sqlite3.Connection) -> List[Listing]:
    rows = con.execute("""
        SELECT listing_id, first_seen_utc, last_seen_utc, is_active, first_price_uah
        FROM listings
    """).fetchall()
    out: List[Listing] = []
    for r in rows:
        out.append(Listing(
            listing_id=r["listing_id"],
            first_seen_utc=r["first_seen_utc"],
            last_seen_utc=r["last_seen_utc"],
            is_active=int(r["is_active"]),
            first_price_uah=float(r["first_price_uah"]) if r["first_price_uah"] is not None else None,
        ))
    return out


def median(values: List[float]) -> float:
    v = sorted(values)
    n = len(v)
    if n == 0:
        return float("nan")
    if n % 2 == 1:
        return v[n // 2]
    return 0.5 * (v[n // 2 - 1] + v[n // 2])


def km_curve(durations: List[int], events: List[int]) -> Dict[str, List[float]]:
    """
    Kaplan–Meier survival estimate S(t).
    durations: time to event/censor (days)
    events: 1 if event happened (disappeared), 0 if censored (still active)
    """
    pairs = sorted(zip(durations, events), key=lambda x: x[0])
    times = sorted(set(d for d, e in pairs if d is not None and d >= 0))

    n_at_risk = len(pairs)
    S = 1.0
    out_t = [0.0]
    out_S = [1.0]

    idx = 0
    for t in times:
        d_i = 0
        c_i = 0
        while idx < len(pairs) and pairs[idx][0] == t:
            if pairs[idx][1] == 1:
                d_i += 1
            else:
                c_i += 1
            idx += 1

        if n_at_risk > 0:
            if d_i > 0:
                S *= (1.0 - d_i / n_at_risk)
            out_t.append(float(t))
            out_S.append(float(S))

        n_at_risk -= (d_i + c_i)
        if n_at_risk <= 0:
            break

    return {"t": out_t, "S": out_S}


def make_bins() -> List[Tuple[float, float, str]]:
    return [
        (-math.inf, 0.95, "<= 0.95x"),
        (0.95, 1.00, "0.95–1.00x"),
        (1.00, 1.05, "1.00–1.05x"),
        (1.05, math.inf, ">= 1.05x"),
    ]


def build_dashboard(data: dict, out_html: str) -> None:
    tpl = f"""<!doctype html>
<html lang="uk">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>OLX Panel — survival dashboard</title>
  <script src="https://cdn.plot.ly/plotly-2.30.0.min.js"></script>
  <style>
    :root {{
      --bg:#0b0f14; --panel:#111824; --text:#e9eef6; --muted:#9fb0c3; --border:rgba(255,255,255,.12);
    }}
    body {{ margin:0; background:var(--bg); color:var(--text); font-family:system-ui,-apple-system,Segoe UI,Roboto,Arial,sans-serif; }}
    header {{ padding:14px 16px; border-bottom:1px solid var(--border); }}
    header h1 {{ margin:0 0 6px 0; font-size:18px; }}
    header p {{ margin:0; color:var(--muted); font-size:13px; line-height:1.35; }}
    .wrap {{ display:grid; grid-template-columns: 420px 1fr; gap:12px; padding:12px; }}
    @media (max-width: 980px) {{ .wrap {{ grid-template-columns:1fr; }} }}
    .card {{ background:var(--panel); border:1px solid var(--border); border-radius:14px; overflow:hidden; }}
    .card h2 {{ margin:0; padding:12px 14px; font-size:14px; border-bottom:1px solid var(--border); }}
    .card .content {{ padding:12px 14px; }}
    label {{ display:block; margin:10px 0 6px; color:var(--muted); font-size:12px; }}
    input {{ width:100%; padding:10px; border-radius:10px; border:1px solid var(--border); background:rgba(255,255,255,.04); color:var(--text); }}
    .kpi {{ display:grid; grid-template-columns: 1fr 1fr; gap:10px; margin-top:10px; }}
    .kpi .box {{ border:1px solid var(--border); border-radius:12px; padding:10px; background:rgba(255,255,255,.03); }}
    .kpi .t {{ font-size:12px; color:var(--muted); margin-bottom:6px; }}
    .kpi .v {{ font-size:16px; font-weight:800; }}
    .chart {{ height: 520px; }}
    .hint {{ color:var(--muted); font-size:12px; line-height:1.35; }}
  </style>
</head>
<body>
<header>
  <h1>OLX panel: «ймовірність, що лот ще активний» vs час</h1>
  <p>Подія = «зник з OLX» (продано або видалено). Бінуємо по відносній стартовій ціні (до медіани).</p>
</header>

<div class="wrap">
  <div class="card">
    <h2>Параметри (для свого лота)</h2>
    <div class="content">
      <label>Базова “ринкова” ціна (грн)</label>
      <input id="baseline" type="number" step="100" value="{int(data.get('market_median_uah', 60000))}" />
      <label>Твоя ціна (грн)</label>
      <input id="yourPrice" type="number" step="100" value="{int(data.get('market_median_uah', 60000))}" />
      <div class="kpi">
        <div class="box">
          <div class="t">Відносна ціна</div>
          <div class="v" id="kRel">—</div>
        </div>
        <div class="box">
          <div class="t">Підказка</div>
          <div class="v" id="kHint">—</div>
        </div>
      </div>
      <div class="hint" style="margin-top:12px;">
        Якщо криві для нижчих діапазонів (<=0.95x) падають швидше — дешевші лоти зазвичай “зникають” швидше.
      </div>
    </div>
  </div>

  <div class="card">
    <h2>Survival криві по бін-діапазонах</h2>
    <div class="content">
      <div id="chart" class="chart"></div>
      <div class="hint" id="note"></div>
    </div>
  </div>
</div>

<script>
  const DATA = {json.dumps(data, ensure_ascii=False)};

  function fmt(x) {{
    return (Math.round(x * 100) / 100).toFixed(2) + "x";
  }}

  function render() {{
    const baseline = Number(document.getElementById("baseline").value || 0);
    const yourPrice = Number(document.getElementById("yourPrice").value || 0);
    const rel = baseline > 0 ? (yourPrice / baseline) : NaN;

    document.getElementById("kRel").textContent = isFinite(rel) ? fmt(rel) : "—";

    let hint = "—";
    if (isFinite(rel)) {{
      if (rel <= 0.95) hint = "<=0.95x: зазвичай швидше";
      else if (rel <= 1.00) hint = "0.95–1.00x: близько до ринку";
      else if (rel <= 1.05) hint = "1.00–1.05x: трохи вище";
      else hint = ">=1.05x: відчутно вище — може висіти";
    }}
    document.getElementById("kHint").textContent = hint;

    const traces = [];
    for (const bin of DATA.bins) {{
      traces.push({{
        x: bin.curve.t,
        y: bin.curve.S,
        mode: "lines",
        type: "scatter",
        name: bin.label + ` (n=${{bin.n}})`,
        hovertemplate: "День: %{{x}}<br>S(t): %{{y:.3f}}<extra></extra>"
      }});
    }}

    const layout = {{
      margin: {{ l: 60, r: 18, t: 10, b: 55 }},
      paper_bgcolor: "rgba(0,0,0,0)",
      plot_bgcolor: "rgba(255,255,255,0.02)",
      xaxis: {{ title: "Дні з моменту first_seen", gridcolor: "rgba(255,255,255,0.08)", rangemode:"tozero" }},
      yaxis: {{ title: "S(t): ймовірність, що лот ще активний", gridcolor: "rgba(255,255,255,0.08)", rangemode:"tozero" }},
      legend: {{ orientation:"h", y: 1.08, x: 0 }},
      hovermode: "closest"
    }};

    Plotly.react("chart", traces, layout, {{responsive:true, displaylogo:false}});

    document.getElementById("note").textContent =
      `Лотів: ${DATA.n_listings}. Медіана стартових цін: ${Math.round(DATA.market_median_uah)} грн. Згенеровано: ${DATA.generated_utc}`;
  }}

  document.getElementById("baseline").addEventListener("input", render);
  document.getElementById("yourPrice").addEventListener("input", render);
  render();
</script>
</body>
</html>
"""
    Path(out_html).write_text(tpl, encoding="utf-8")


def main() -> int:
    ap = argparse.ArgumentParser(description="Analyze OLX panel DB and build an interactive dashboard")
    ap.add_argument("--db", default="olx_panel.sqlite3", help="SQLite DB path")
    ap.add_argument("--out", default="olx_panel_dashboard.html", help="Output HTML path")
    args = ap.parse_args()

    con = connect(args.db)
    listings = load_listings(con)

    start_prices = [l.first_price_uah for l in listings if l.first_price_uah is not None and l.first_price_uah > 0]
    if not start_prices:
        raise SystemExit("No start prices. Run seed/update first.")

    mmed = median(start_prices)

    rows = []
    for l in listings:
        if l.first_price_uah is None or l.first_price_uah <= 0:
            continue
        duration = days_between(l.first_seen_utc, l.last_seen_utc)
        event = 1 if int(l.is_active) == 0 else 0
        rel = float(l.first_price_uah) / mmed if mmed > 0 else float("nan")
        rows.append((duration, event, rel))

    bins = make_bins()
    out_bins = []
    for lo, hi, label in bins:
        durs = [d for (d, e, rel) in rows if rel > lo and rel <= hi]
        evs  = [e for (d, e, rel) in rows if rel > lo and rel <= hi]
        curve = km_curve(durs, evs) if len(durs) >= 5 else {"t":[0.0],"S":[1.0]}
        out_bins.append({"label": label, "n": len(durs), "curve": curve})

    data = {
        "n_listings": len(rows),
        "market_median_uah": mmed,
        "bins": out_bins,
        "generated_utc": dt.datetime.utcnow().replace(microsecond=0).isoformat() + "Z",
    }

    build_dashboard(data, args.out)
    print(f"Wrote: {args.out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
