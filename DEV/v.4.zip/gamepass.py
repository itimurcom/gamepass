#!/usr/bin/env python3
# gamepass.py — Game Pass каталог (v4.1 Visual Fix)
#
# Логіка: Надійна (v4.0) — спочатку кеш, потім мережа, гарантований експорт.
# Вигляд: Красивий (v3.0) — кольори, теги, прогрес-бар.
#
# Вимагає поруч файл: template.html

import argparse
import csv
import json
import os
import random
import sys
import time
import urllib.parse
import urllib.request
from datetime import datetime

# ---------- CLI & CONFIG ----------
def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--quiet", action="store_true", help="Вимкнути вивід")
    p.add_argument("--no-color", action="store_true", help="Вимкнути кольори")
    p.add_argument("--reset-cache", action="store_true", help="Скинути кеш")
    p.add_argument("--render-only", action="store_true", help="Тільки генерація (офлайн)")
    p.add_argument("--no-wikidata", action="store_true", help="Без Wikidata")
    p.add_argument("--hltb", action="store_true", help="З HowLongToBeat")
    p.add_argument("--market", default="US")
    p.add_argument("--pass-size", type=int, default=100)
    return p.parse_args()

ARGS = parse_args()

try: from tqdm import tqdm
except: tqdm = None

# Налаштування
MARKET = ARGS.market
DATA_LANG = "uk-ua"
DISPLAY_LANGS = "uk-ua,en-us"
SIGL_ALL = "29a81209-df6f-41fd-a528-2ae6b91f719c"
CACHE_DIR = os.path.join(os.path.expanduser("~"), ".gamepass")

DIRS = {
    "products": os.path.join(CACHE_DIR, "products"),
    "wikidata": os.path.join(CACHE_DIR, "wikidata"),
    "wd_sparql": os.path.join(CACHE_DIR, "wd_sparql"),
    "hltb": os.path.join(CACHE_DIR, "hltb")
}
FILES = {
    "sigl": os.path.join(CACHE_DIR, "sigl_ids.json"),
    "template": "template.html",
    "out_html": "gamepass_catalog.html",
    "out_csv": "gamepass_catalog.csv"
}
SCHEMA_VER = 3

# ---------- VISUALS (Повернення стилю) ----------
IS_TTY = sys.stdout.isatty()
USE_COLOR = (not ARGS.no_color) and IS_TTY

def _c(txt, kind):
    if not USE_COLOR: return txt
    colors = {
        "reset": "\033[0m", "bold": "\033[1m", "dim": "\033[2m",
        "red": "\033[31m", "green": "\033[32m", "yellow": "\033[33m",
        "blue": "\033[34m", "cyan": "\033[36m"
    }
    return f"{colors.get(kind, '')}{txt}{colors['reset']}"

def _tag(label, color="blue"):
    return _c(f"[{label}]", color)

def log(msg, tag_txt=None, tag_color="blue"):
    if ARGS.quiet: return
    prefix = f"{_tag(tag_txt, tag_color)} " if tag_txt else ""
    print(f"{prefix}{msg}")

def log_warn(msg):
    log(msg, "УВАГА", "yellow")

def log_err(msg):
    print(f"{_tag('ПОМИЛКА', 'red')} {msg}")

# ---------- UTILS ----------
def ensure_dirs():
    os.makedirs(CACHE_DIR, exist_ok=True)
    for d in DIRS.values(): os.makedirs(d, exist_ok=True)

def rw_json(path, data=None):
    if data is None: # Read
        if os.path.exists(path):
            try:
                with open(path, "r", encoding="utf-8") as f: return json.load(f)
            except: pass
        return None
    else: # Write
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f: json.dump(data, f, ensure_ascii=False, indent=2)
        os.replace(tmp, path)

def safe_name(s): return "".join(c for c in (s or "").lower() if c.isalnum() or c in "-_")[:180] or "x"

def http_get_json(url, headers=None):
    h = {"User-Agent": "Mozilla/5.0", "Accept": "application/json"}
    if headers: h.update(headers)
    for i in range(3):
        try:
            req = urllib.request.Request(url, headers=h)
            with urllib.request.urlopen(req, timeout=20) as r: return json.loads(r.read())
        except Exception as e:
            time.sleep(1 + random.random())
    return None

# ---------- LOGIC ----------

def get_sigl_ids():
    cached = rw_json(FILES["sigl"])
    if cached and cached.get("ids") and cached.get("market") == MARKET:
        log(f"Завантажено з кешу: {_c(str(len(cached['ids'])), 'bold')} ігор", "SIGL", "green")
        return [str(x) for x in cached["ids"]]
    
    log("Отримання списку ігор з серверів Xbox...", "SIGL", "cyan")
    url = "https://catalog.gamepass.com/sigls/v2?" + urllib.parse.urlencode({"id": SIGL_ALL, "language": DATA_LANG, "market": MARKET})
    data = http_get_json(url)
    ids = []
    if isinstance(data, list):
        ids = list(set(str(item.get("id") or item.get("productId") or "") for item in data if item.get("id") or item.get("productId")))
    
    ids = [x for x in ids if x]
    rw_json(FILES["sigl"], {"_schema": SCHEMA_VER, "market": MARKET, "ids": ids})
    log(f"Отримано нових ID: {_c(str(len(ids)), 'bold')}", "SIGL", "green")
    return ids

def fetch_store_batch(ids):
    if not ids: return
    url = "https://displaycatalog.mp.microsoft.com/v7.0/products?" + urllib.parse.urlencode(
        {"bigIds": ",".join(ids), "market": MARKET, "languages": DISPLAY_LANGS}, quote_via=urllib.parse.quote)
    data = http_get_json(url)
    if not data or "Products" not in data: return
    
    for p in data["Products"]:
        bid = p.get("ProductId") or p.get("BigId")
        if bid:
            rw_json(os.path.join(DIRS["products"], f"{safe_name(bid)}.json"), 
                   {"_schema": SCHEMA_VER, "display_langs": DISPLAY_LANGS, "product": p})

def get_product_data(bid):
    # Тільки читання з диска
    cache = rw_json(os.path.join(DIRS["products"], f"{safe_name(bid)}.json"))
    if not cache or "product" not in cache: return None
    p = cache["product"]
    
    lps = p.get("LocalizedProperties", [])
    lp = next((x for x in lps if x.get("Language","").lower() == DATA_LANG), lps[0] if lps else {})
    props = p.get("Properties", {})
    
    imgs = lp.get("Images", [])
    if not imgs and p.get("DisplaySkuAvailabilities"):
        imgs = p.get("DisplaySkuAvailabilities")[0].get("Sku", {}).get("LocalizedProperties", [{}])[0].get("Images", [])
    img_url = next((i.get("Uri") for i in imgs if i.get("ImagePurpose") in ["Poster", "BoxArt"]), imgs[0].get("Uri") if imgs else "")
    if img_url and img_url.startswith("//"): img_url = "https:" + img_url

    name = lp.get("ProductTitle") or p.get("ProductTitle") or ""
    if not name: return None

    search_name = name.replace("(Game Preview)", "").replace("(PC)", "").strip()
    wd_cache_name = rw_json(os.path.join(DIRS["wikidata"], f"{safe_name(search_name)}.json"))
    qid = wd_cache_name.get("qid") if wd_cache_name else None
    
    wd_data = {}
    if qid:
        wd_raw = rw_json(os.path.join(DIRS["wd_sparql"], f"{safe_name(qid)}.json"))
        if wd_raw and "data" in wd_raw: wd_data = wd_raw["data"]

    hltb_raw = rw_json(os.path.join(DIRS["hltb"], f"{safe_name(search_name)}.json"))
    hours = hltb_raw.get("hours","") if hltb_raw else ""

    return {
        "id": bid,
        "name": name,
        "genre": wd_data.get("Genres_UK") or lp.get("ShortDescription",""),
        "description": wd_data.get("Description_UK") or lp.get("ShortDescription",""),
        "rating": wd_data.get("Rating",""),
        "ratingSource": wd_data.get("RatingSource",""),
        "year": wd_data.get("Year_WD") or (props.get("OriginalReleaseDate") or "")[:4],
        "hours": hours,
        "publisher": lp.get("PublisherName",""),
        "developer": lp.get("DeveloperName",""),
        "wikipedia": wd_data.get("WikipediaUrl",""),
        "wikidata": wd_data.get("WikidataUrl",""),
        "image": img_url
    }

def enrich_one(name):
    # Ця функція виконується тільки якщо немає кешу
    if not ARGS.no_wikidata:
        path_n = os.path.join(DIRS["wikidata"], f"{safe_name(name)}.json")
        if not os.path.exists(path_n):
            u = "https://www.wikidata.org/w/api.php?" + urllib.parse.urlencode(
                {"action": "wbsearchentities", "search": name, "language": "en", "format": "json", "limit": 1, "type": "item"})
            d = http_get_json(u)
            qid = d["search"][0]["id"] if d and d.get("search") else None
            rw_json(path_n, {"_schema": SCHEMA_VER, "name": name, "qid": qid})
            
            if qid:
                path_q = os.path.join(DIRS["wd_sparql"], f"{safe_name(qid)}.json")
                if not os.path.exists(path_q):
                    q = f"""SELECT ?item ?desc_uk (GROUP_CONCAT(DISTINCT ?genreLabel_uk; separator=", ") AS ?genres_uk) (MIN(?pubDate) AS ?pubDateMin) ?score ?reviewerLabel ?wikipedia WHERE {{
                      BIND(wd:{qid} AS ?item)
                      OPTIONAL {{ ?item schema:description ?desc_uk FILTER(LANG(?desc_uk)="uk") }}
                      OPTIONAL {{ ?item wdt:P136 ?genre . OPTIONAL {{ ?genre rdfs:label ?genreLabel_uk FILTER(LANG(?genreLabel_uk)="uk") }} }}
                      OPTIONAL {{ ?item wdt:P577 ?pubDate . }}
                      OPTIONAL {{ ?item p:P444 ?s . ?s ps:P444 ?score . OPTIONAL {{ ?s pq:P447 ?reviewer . }} }}
                      OPTIONAL {{ ?wikipedia schema:about ?item ; schema:isPartOf <https://en.wikipedia.org/> . }}
                      SERVICE wikibase:label {{ bd:serviceParam wikibase:language "uk". ?reviewer rdfs:label ?reviewerLabel . }}
                    }} GROUP BY ?item ?desc_uk ?score ?reviewerLabel ?wikipedia"""
                    wd_res = http_get_json("https://query.wikidata.org/sparql?" + urllib.parse.urlencode({"format":"json", "query":q}))
                    
                    data_parsed = {}
                    if wd_res:
                        try:
                            r = wd_res["results"]["bindings"][0]
                            data_parsed = {
                                "Genres_UK": r.get("genres_uk",{}).get("value",""),
                                "Description_UK": r.get("desc_uk",{}).get("value",""),
                                "Year_WD": (r.get("pubDateMin",{}).get("value","") or "")[:4],
                                "Rating": r.get("score",{}).get("value",""),
                                "RatingSource": r.get("reviewerLabel",{}).get("value",""),
                                "WikipediaUrl": r.get("wikipedia",{}).get("value",""),
                                "WikidataUrl": f"https://www.wikidata.org/wiki/{qid}"
                            }
                        except: pass
                    rw_json(path_q, {"_schema": SCHEMA_VER, "qid": qid, "data": data_parsed})

    if ARGS.hltb:
        path_h = os.path.join(DIRS["hltb"], f"{safe_name(name)}.json")
        if not os.path.exists(path_h):
            try:
                from howlongtobeatpy import HowLongToBeat
                res = HowLongToBeat().search(name)
                h = str(res[0].main_story) if res else ""
                rw_json(path_h, {"_schema": SCHEMA_VER, "name": name, "hours": h})
            except: pass

# ---------- MAIN ----------
def main():
    ensure_dirs()
    print()
    if ARGS.reset_cache:
        import shutil
        shutil.rmtree(CACHE_DIR)
        ensure_dirs()
        log_warn("Кеш очищено!")

    # 1. SIGL
    ids = get_sigl_ids()

    if not ARGS.render_only:
        # 2. STORE
        missing_store = [x for x in ids if not os.path.exists(os.path.join(DIRS["products"], f"{safe_name(x)}.json"))]
        
        if missing_store:
            log(f"Потрібно завантажити: {_c(str(len(missing_store)), 'bold')}", "МАГАЗИН", "blue")
            bs = ARGS.pass_size
            chunks = [missing_store[i:i + bs] for i in range(0, len(missing_store), bs)]
            
            iter_obj = tqdm(chunks, desc=f"{_tag('МАГАЗИН', 'blue')} Завантаження", unit="пак") if tqdm else chunks
            for chunk in iter_obj:
                fetch_store_batch(chunk)
                time.sleep(0.5)
        else:
            log("Всі дані магазину актуальні", "МАГАЗИН", "green")
        
        # 3. ENRICH
        log("Перевірка метаданих...", "ДЕТАЛІ", "cyan")
        cached_ids = [x for x in ids if os.path.exists(os.path.join(DIRS["products"], f"{safe_name(x)}.json"))]
        
        # Ми хочемо показати прогрес бар навіть для перевірки (бо це швидкий IO)
        iter_obj = tqdm(cached_ids, desc=f"{_tag('ДЕТАЛІ', 'cyan')} Аналіз", unit="гра") if tqdm else cached_ids
        for bid in iter_obj:
            d = get_product_data(bid)
            if d:
                # enrich_one лізе в мережу ТІЛЬКИ якщо немає файлу, інакше просто скіпає
                enrich_one(d["name"].replace("(Game Preview)", "").replace("(PC)", "").strip())

    # 4. EXPORT
    log("Генерація фінальних звітів...", "ЕКСПОРТ", "yellow")
    rows = []
    for bid in ids:
        row = get_product_data(bid)
        if row: rows.append(row)
    
    # CSV
    cols = ["id","name","genre","description","rating","ratingSource","year","hours","publisher","developer","wikipedia","wikidata","image"]
    with open(FILES["out_csv"], "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=cols)
        w.writeheader()
        for r in rows: w.writerow({k: r.get(k,"") for k in cols})

    # HTML
    if not os.path.exists(FILES["template"]):
        log_err(f"Файл {FILES['template']} не знайдено! Тільки CSV.")
    else:
        with open(FILES["template"], "r", encoding="utf-8") as f: tmpl = f.read()
        now = datetime.now().strftime('%Y-%m-%d %H:%M')
        html_out = tmpl.replace("__TITLE__", f"Game Pass {MARKET} ({now})")
        html_out = html_out.replace("__DATA_JSON__", json.dumps(rows, ensure_ascii=False))
        with open(FILES["out_html"], "w", encoding="utf-8") as f: f.write(html_out)
        
        log(f"HTML: {_c(FILES['out_html'], 'bold')}", "ГОТОВО", "green")
        log(f"CSV:  {_c(FILES['out_csv'], 'bold')}", "ГОТОВО", "green")
        log(f"Всього записів: {_c(str(len(rows)), 'bold')}", "СТАТ", "green")

    print()

if __name__ == "__main__":
    try: main()
    except KeyboardInterrupt:
        print()
        log_warn("Зупинено користувачем.")
        sys.exit(0)