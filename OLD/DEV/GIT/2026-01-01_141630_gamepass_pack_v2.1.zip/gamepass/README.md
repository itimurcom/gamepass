# Game Pass Catalog (v2.1)

## Changes in v2.1
- Platforms handling removed completely.
- Description column moved right after Genre.
- Rating column: fixed width + ellipsis; in TABLE shows only numeric value (0-100).
  Rating source is available as tooltip (hover) and kept in CSV/data.

## Run
```bash
chmod +x gamepass.py
./gamepass.py
```

### Options
- `--reset-cache` – clear cache and start over
- `--no-wikidata` – skip Wikidata enrichment
- `--hltb` – try to fetch hours from HowLongToBeat (requires dependency)
- `--pass-size 100` – fetch pass size
- `--quiet` – less console output

## Optional deps (recommended)
Install via venv on Ubuntu/Debian (PEP 668):
```bash
sudo apt install -y python3-venv python3-full
python3 -m venv .venv
source .venv/bin/activate
pip install tqdm howlongtobeatpy
./gamepass.py --hltb
```

Without these deps, script still works; progress uses informative heartbeat and hours stay empty.
