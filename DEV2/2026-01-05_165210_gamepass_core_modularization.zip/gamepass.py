#!/usr/bin/env python3
"""
PC Game Pass catalog dumper (EN/US only) - stdlib only

Output:
  .cache/            one raw Microsoft Store product JSON per game (ProductId.json)
  .cache/_meta/      meta files (SIGL dump etc.)
"""

from __future__ import annotations

import time
from pathlib import Path

from core.config import Config, PC_GAMEPASS_SIGL
from core.displaycatalog import fetch_products
from core.fs import ensure_dirs, write_json, write_product
from core.logging import log
from core.sigl import fetch_sigl_big_ids
from core.utils import chunked


def run(cfg: Config) -> None:
    meta_dir = ensure_dirs(cfg.out_dir)

    log(f"[sigl] Fetching PC Game Pass list: sigl={cfg.sigl_id} market={cfg.market} lang={cfg.language}")
    ids, sigl_meta = fetch_sigl_big_ids(cfg)
    write_json(meta_dir / "sigl_US_en-us.json", sigl_meta)

    for batch in chunked(sorted(ids), cfg.batch_size):
        products = fetch_products(cfg, batch)
        for p in products:
            if isinstance(p, dict):
                write_product(cfg.out_dir, p)
        time.sleep(cfg.sleep_s)


def main() -> None:
    cfg = Config(
        market="US",
        language="en-us",
        out_dir=Path(".cache"),
        sigl_id=PC_GAMEPASS_SIGL,
        batch_size=100,
        sleep_s=0.2,
        timeout_s=30.0,
        retries=3,
    )
    run(cfg)


if __name__ == "__main__":
    main()
